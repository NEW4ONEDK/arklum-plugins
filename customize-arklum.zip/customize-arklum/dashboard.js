(function() {
  var currentTab = 'login';

  window.switchTab = function(tab) {
    currentTab = tab;
    document.getElementById('tab-login').classList.toggle('active', tab === 'login');
    document.getElementById('tab-loading').classList.toggle('active', tab === 'loading');
    document.getElementById('tab-sidebar').classList.toggle('active', tab === 'sidebar');
    document.getElementById('tab-header').classList.toggle('active', tab === 'header');
    document.getElementById('tab-cards').classList.toggle('active', tab === 'cards');
    document.getElementById('tab-chat').classList.toggle('active', tab === 'chat');
    document.getElementById('section-login').style.display = tab === 'login' ? 'block' : 'none';
    document.getElementById('section-loading').style.display = tab === 'loading' ? 'block' : 'none';
    document.getElementById('section-sidebar').style.display = tab === 'sidebar' ? 'block' : 'none';
    document.getElementById('section-header').style.display = tab === 'header' ? 'block' : 'none';
    document.getElementById('section-cards').style.display = tab === 'cards' ? 'block' : 'none';
    document.getElementById('section-chat').style.display = tab === 'chat' ? 'block' : 'none';
  };

  var loginPresets = {
    default: {
      label: 'Arklum Default',
      vars: {},
      art: '<div style="font-size:2rem;text-align:center;margin:0 auto 8px;">●</div><div style="text-align:center;font-weight:600;">Default</div>',
      previewHtml: '<div class="login-card-preview" style="max-width:300px;margin:0 auto;background:rgba(22,24,28,0.55);border:1px solid rgba(255,255,255,0.08);border-radius:24px;padding:28px 20px;text-align:center;color:#e8e6e3;box-shadow:0 12px 32px rgba(0,0,0,0.5);position:relative;overflow:visible;"><h1 style="font-size:1.5rem;letter-spacing:3px;margin-bottom:12px;background:linear-gradient(135deg,#00d4aa,#4a4aff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">ARKLUM</h1><input style="width:100%;padding:10px;border-radius:10px;border:1px solid rgba(255,255,255,0.08);background:rgba(0,0,0,0.25);color:#e8e6e3;margin-bottom:10px;text-align:center;" readonly value="••••••"><button style="width:100%;padding:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#00d4aa,#4a4aff);color:#fff;font-weight:700;cursor:default;">Verify Token</button></div>'
    },
    capybara: {
      label: 'Capybara',
      vars: {
        '--login-card-bg': 'rgba(100, 60, 40, 0.55)',
        '--login-card-border': '#8b5e3c',
        '--login-card-text': '#fff9f0',
        '--login-title-gradient': 'linear-gradient(135deg, #ffa726, #ef6c00)',
        '--login-input-bg': '#5c3a20',
        '--login-input-text': '#fff9f0',
        '--login-input-border': '#8b5e3c',
        '--login-btn-primary-bg': 'linear-gradient(145deg, #ffa726, #ef6c00)',
        '--login-btn-primary-text': '#fff'
      },
      art: '<div style="width:48px;height:32px;background:radial-gradient(circle at 50% 38%,#ffa726 12px,#ef6c00 14px);border-radius:50%;box-shadow:-38px 6px 0 -10px #b08050,-38px 6px 0 -7px #8b5e3c,38px 6px 0 -10px #b08050,38px 6px 0 -7px #8b5e3c;margin:0 auto 8px;"></div><div style="text-align:center;font-weight:600;">Capybara</div>',
      previewHtml: '<div class="login-card-preview" style="max-width:300px;margin:0 auto;background:rgba(100,60,40,0.55);border:1px solid #8b5e3c;border-radius:24px;padding:28px 20px;text-align:center;color:#fff9f0;box-shadow:0 12px 32px rgba(0,0,0,0.5);position:relative;overflow:visible;"><div style="position:absolute;top:-26px;left:50%;transform:translateX(-50%);width:38px;height:22px;background:radial-gradient(circle at 50% 38%,#ffa726 10px,#ef6c00 12px);border-radius:50%;box-shadow:-30px 4px 0 -8px #b08050,-30px 4px 0 -6px #8b5e3c,30px 4px 0 -8px #b08050,30px 4px 0 -6px #8b5e3c;z-index:3;"></div><h1 style="font-size:1.5rem;letter-spacing:3px;margin-bottom:12px;color:#ffa726;text-shadow:0 0 12px rgba(255,167,38,0.5);">ARKLUM</h1><div style="background:#5c3a20;border:1px solid #8b5e3c;border-radius:10px;padding:6px;margin-bottom:10px;"><div style="display:flex;justify-content:space-between;align-items:center;padding:6px;font-size:0.8rem;color:#fff9f0;"><span>Token Name</span><span style="cursor:pointer;">Login</span></div></div><input style="width:100%;padding:10px;border-radius:10px;border:none;background:#5c3a20;color:#fff9f0;margin-bottom:10px;text-align:center;font-family:inherit;" readonly value="••••••"><button style="width:100%;padding:10px;border:none;border-radius:10px;background:linear-gradient(145deg,#ffa726,#ef6c00);color:#fff;font-weight:700;cursor:default;">Verify Token</button></div>'
    },
    dino: {
      label: 'Dino',
      vars: {
        '--login-card-bg': 'rgba(0, 130, 140, 0.5)',
        '--login-card-border': '#006064',
        '--login-card-text': '#fff',
        '--login-title-gradient': 'linear-gradient(135deg, #00e5ff, #00838f)',
        '--login-input-bg': '#004d52',
        '--login-input-text': '#fff',
        '--login-input-border': '#006064',
        '--login-btn-primary-bg': 'linear-gradient(135deg, #00e5ff, #00838f)',
        '--login-btn-primary-text': '#000'
      },
      art: '<div style="width:60px;height:12px;background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Dino</div>',
      previewHtml: '<div class="login-card-preview" style="max-width:300px;margin:0 auto;background:rgba(0,130,140,0.5);border:1px solid #006064;border-radius:24px;padding:28px 20px;text-align:center;color:#fff;box-shadow:0 12px 32px rgba(0,0,0,0.5);position:relative;overflow:visible;"><div style="position:absolute;top:-12px;left:15px;width:calc(100% - 30px);height:12px;background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);z-index:2;"></div><h1 style="font-size:1.5rem;letter-spacing:3px;margin-bottom:12px;color:#00e5ff;text-shadow:0 0 10px rgba(0,229,255,0.6);">ARKLUM</h1><div style="background:#004d52;border:1px solid #006064;border-radius:10px;padding:6px;margin-bottom:10px;"><div style="display:flex;justify-content:space-between;align-items:center;padding:6px;font-size:0.8rem;color:#fff;"><span>Token Name</span><span style="cursor:pointer;">Login</span></div></div><input style="width:100%;padding:10px;border-radius:10px;border:none;background:#004d52;color:#fff;margin-bottom:10px;text-align:center;font-family:inherit;" readonly value="••••••"><button style="width:100%;padding:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#00e5ff,#00838f);color:#000;font-weight:700;cursor:default;">Verify Token</button></div>'
    },
    frogduck: {
      label: 'Frog Duck',
      vars: {
        '--login-card-bg': 'rgba(100, 150, 50, 0.5)',
        '--login-card-border': '#558b2f',
        '--login-card-text': '#dcedc8',
        '--login-title-gradient': 'linear-gradient(135deg, #aed581, #7cb342)',
        '--login-input-bg': '#33691e',
        '--login-input-text': '#dcedc8',
        '--login-input-border': '#558b2f',
        '--login-btn-primary-bg': 'linear-gradient(135deg, #7cb342, #558b2f)',
        '--login-btn-primary-text': '#000'
      },
      art: '<div style="display:flex;gap:24px;margin:0 auto 8px;justify-content:center;"><div style="width:22px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div><div style="width:22px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div></div><div style="text-align:center;font-weight:600;">Frog Duck</div>',
      previewHtml: '<div class="login-card-preview" style="max-width:300px;margin:0 auto;background:rgba(100,150,50,0.5);border:1px solid #558b2f;border-radius:24px;padding:28px 20px;text-align:center;color:#dcedc8;box-shadow:0 12px 32px rgba(0,0,0,0.5);position:relative;overflow:visible;"><div style="position:absolute;top:-20px;left:18px;width:22px;height:22px;background:#fff;border:4px solid #2e7d32;border-radius:50%;box-shadow:34px 0 0 #fff,34px 0 0 4px #2e7d32,8px 6px 0 5px #000,42px 6px 0 5px #000;z-index:3;"></div><h1 style="font-size:1.5rem;letter-spacing:3px;margin-bottom:12px;color:#aed581;">ARKLUM</h1><div style="background:#33691e;border:1px solid #558b2f;border-radius:10px;padding:6px;margin-bottom:10px;"><div style="display:flex;justify-content:space-between;align-items:center;padding:6px;font-size:0.8rem;color:#dcedc8;"><span>Token Name</span><span style="cursor:pointer;">Login</span></div></div><input style="width:100%;padding:10px;border-radius:10px;border:none;background:#33691e;color:#dcedc8;margin-bottom:10px;text-align:center;font-family:inherit;" readonly value="••••••"><button style="width:100%;padding:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#7cb342,#558b2f);color:#000;font-weight:700;cursor:default;">Verify Token</button></div>'
    },
    shark: {
      label: 'Shark',
      vars: {
        '--login-card-bg': 'rgba(20, 60, 120, 0.55)',
        '--login-card-border': '#1565c0',
        '--login-card-text': '#e3f2fd',
        '--login-title-gradient': 'linear-gradient(135deg, #1e88e5, #0d47a1)',
        '--login-input-bg': '#0d47a1',
        '--login-input-text': '#fff',
        '--login-input-border': '#1565c0',
        '--login-btn-primary-bg': 'linear-gradient(135deg, #1e88e5, #0d47a1)',
        '--login-btn-primary-text': '#fff'
      },
      art: '<div style="width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);margin:0 auto 8px;"></div><div style="text-align:center;font-weight:600;">Shark</div>',
      previewHtml: '<div class="login-card-preview" style="max-width:300px;margin:0 auto;background:rgba(20,60,120,0.55);border:1px solid #1565c0;border-radius:24px;padding:28px 20px;text-align:center;color:#e3f2fd;box-shadow:0 12px 32px rgba(0,0,0,0.5);position:relative;overflow:visible;"><div style="position:absolute;top:-18px;right:20px;width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);z-index:2;"></div><h1 style="font-size:1.5rem;letter-spacing:3px;margin-bottom:12px;color:#1e88e5;text-shadow:0 0 12px rgba(30,136,229,0.5);">ARKLUM</h1><div style="background:#0d47a1;border:1px solid #1565c0;border-radius:10px;padding:6px;margin-bottom:10px;"><div style="display:flex;justify-content:space-between;align-items:center;padding:6px;font-size:0.8rem;color:#fff;"><span>Token Name</span><span style="cursor:pointer;">Login</span></div></div><input style="width:100%;padding:10px;border-radius:10px;border:none;background:#0d47a1;color:#fff;margin-bottom:10px;text-align:center;font-family:inherit;" readonly value="••••••"><button style="width:100%;padding:10px;border:none;border-radius:10px;background:linear-gradient(135deg,#1e88e5,#0d47a1);color:#fff;font-weight:700;cursor:default;">Verify Token</button></div>'
    }
  };

  var loadingPresets = {
    default: {
      label: 'Ethereum (Default)',
      art: '<div style="font-size:2rem;text-align:center;margin:0 auto 8px;">●</div><div style="text-align:center;font-weight:600;">Default</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;"><div class="ethereum-container" style="width:60px;height:60px;"><svg xmlns="http://w3.org" viewBox="-80 -80 416 577" width="100%" height="100%"><defs><filter id="magnetic-glow-def"><feGaussianBlur stdDeviation="8" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g class="container-cluster"><g class="part-top-left"><path fill="#8a92ff" d="M127.962 0L0 212.32l127.962 75.639V154.158z"/><path fill="#3438cc" d="M0 212.32l127.96 75.638v-133.8z"/></g><g class="part-top-right"><path fill="#454af8" d="M127.961 0l-2.795 9.5v275.668l2.795 2.79 127.962-75.638z"/><path fill="#1a1c72" d="M127.961 287.958l127.96-75.637-127.96-58.162z"/></g><g class="part-bottom-v"><path fill="#8a92ff" d="M127.962 416.905v-104.72L0 236.585z"/><path fill="#3a3edf" d="M127.961 312.187l-1.575 1.92v98.199l1.575 4.6L256 236.587z"/></g></g></svg></div><div style="margin-top:10px;font-size:0.9rem;color:var(--text);">Connecting…</div></div>'
    },
    shark: {
      label: 'Shark Patrol',
      art: '<div style="width:60px;height:4px;background:#0d47a1;border-radius:2px;position:relative;margin:0 auto 20px;"><div style="position:absolute;top:-18px;left:0;width:18px;height:18px;background:#1e88e5;border:2px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);animation:sharkPatrol 3s ease-in-out infinite;"></div></div><div style="text-align:center;font-weight:600;">Shark</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(20,60,120,0.2);border-radius:16px;"><div style="width:120px;height:4px;background:#0d47a1;border-radius:2px;position:relative;"><div class="shark-fin-preview" style="position:absolute;top:-18px;left:0;width:18px;height:18px;background:#1e88e5;border:2px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);animation:sharkPatrol 3s ease-in-out infinite;"></div></div><div style="margin-top:24px;color:#1e88e5;font-weight:600;">Tracking…</div></div>'
    },
    dino: {
      label: 'Dino Wave',
      art: '<div style="width:80px;height:14px;margin:0 auto 10px;position:relative;"><div style="width:100%;height:100%;background:repeating-linear-gradient(90deg,#006064 0px,#006064 10px,transparent 10px,transparent 16px);clip-path:polygon(0% 0%,5px 100%,10px 0%,15px 100%,20px 0%,25px 100%,30px 0%,35px 100%,40px 0%,45px 100%,50px 0%,55px 100%,60px 0%,65px 100%,70px 0%,75px 100%,80px 0%);"></div><div style="position:absolute;top:0;left:0;width:100%;height:100%;background:repeating-linear-gradient(90deg,#00e5ff 0px,#00e5ff 10px,transparent 10px,transparent 16px);clip-path:polygon(0% 0%,5px 100%,10px 0%,15px 100%,20px 0%,25px 100%,30px 0%,35px 100%,40px 0%,45px 100%,50px 0%,55px 100%,60px 0%,65px 100%,70px 0%,75px 100%,80px 0%);mask:linear-gradient(90deg,transparent,#000,transparent);animation:dinoWave 2s linear infinite;"></div></div><div style="text-align:center;font-weight:600;">Dino</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(0,130,140,0.2);border-radius:16px;"><div style="width:120px;height:14px;position:relative;"><div style="width:100%;height:100%;background:repeating-linear-gradient(90deg,#006064 0px,#006064 10px,transparent 10px,transparent 16px);clip-path:polygon(0% 0%,5px 100%,10px 0%,15px 100%,20px 0%,25px 100%,30px 0%,35px 100%,40px 0%,45px 100%,50px 0%,55px 100%,60px 0%,65px 100%,70px 0%,75px 100%,80px 0%);"></div><div style="position:absolute;top:0;left:0;width:100%;height:100%;background:repeating-linear-gradient(90deg,#00e5ff 0px,#00e5ff 10px,transparent 10px,transparent 16px);clip-path:polygon(0% 0%,5px 100%,10px 0%,15px 100%,20px 0%,25px 100%,30px 0%,35px 100%,40px 0%,45px 100%,50px 0%,55px 100%,60px 0%,65px 100%,70px 0%,75px 100%,80px 0%);mask:linear-gradient(90deg,transparent,#000,transparent);animation:dinoWave 2s linear infinite;"></div></div><div style="margin-top:24px;color:#00e5ff;font-weight:600;">Loading…</div></div>'
    },
    capybara: {
      label: 'Capybara Wobble',
      art: '<div style="width:44px;height:30px;background:radial-gradient(circle at 50% 38%,#ffa726 11px,#ef6c00 13px);border-radius:50%;box-shadow:-34px 6px 0 -9px #b08050,-34px 6px 0 -6px #8b5e3c,34px 6px 0 -9px #b08050,34px 6px 0 -6px #8b5e3c;animation:capyWobble 0.8s infinite alternate;margin:0 auto 12px;"></div><div style="width:50px;height:6px;background:rgba(0,0,0,0.4);border-radius:50%;animation:shadowScale 0.8s infinite alternate;margin:0 auto;"></div><div style="text-align:center;font-weight:600;margin-top:4px;">Capybara</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(100,60,40,0.2);border-radius:16px;"><div class="capy-head-preview" style="width:44px;height:30px;background:radial-gradient(circle at 50% 38%,#ffa726 11px,#ef6c00 13px);border-radius:50%;box-shadow:-34px 6px 0 -9px #b08050,-34px 6px 0 -6px #8b5e3c,34px 6px 0 -9px #b08050,34px 6px 0 -6px #8b5e3c;animation:capyWobble 0.8s infinite alternate;"></div><div class="capy-shadow-preview" style="width:50px;height:6px;background:rgba(0,0,0,0.4);border-radius:50%;animation:shadowScale 0.8s infinite alternate;margin-top:12px;"></div><div style="margin-top:16px;color:#ffa726;font-weight:600;">Walking…</div></div>'
    },
    heartpepe: {
      label: 'Heart Pepe Beat',
      art: '<div style="width:28px;height:26px;background:#e53935;clip-path:path(\'M14,22 C14,22 0,13 0,7 C0,2 3,0 6,0 C9,0 14,4 14,4 C14,4 19,0 22,0 C25,0 28,2 28,7 C28,13 14,22 14,22Z\');animation:heartBeat 1.2s infinite;filter:drop-shadow(0 0 6px rgba(229,57,53,0.5));margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Heart Pepe</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(200,120,140,0.2);border-radius:16px;"><div class="heartpepe-preview" style="width:28px;height:26px;background:#e53935;clip-path:path(\'M14,22 C14,22 0,13 0,7 C0,2 3,0 6,0 C9,0 14,4 14,4 C14,4 19,0 22,0 C25,0 28,2 28,7 C28,13 14,22 14,22Z\');animation:heartBeat 1.2s infinite;filter:drop-shadow(0 0 6px rgba(229,57,53,0.5));"></div><div style="margin-top:16px;color:#e53935;font-weight:600;">Syncing…</div></div>'
    },
    frogduck_loader: {
      label: 'Frog Duck Blink',
      art: '<div style="display:flex;gap:22px;margin:0 auto 12px;justify-content:center;"><div class="frogduck-eye-art" style="width:18px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;position:relative;animation:frogBlink 3s infinite;"></div><div class="frogduck-eye-art" style="width:18px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;position:relative;animation:frogBlink 3s infinite;"></div></div><div style="text-align:center;font-weight:600;">Frog Duck</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(100,150,50,0.2);border-radius:16px;"><div style="display:flex;gap:22px;margin-bottom:12px;"><div class="frogduck-eye-preview" style="width:18px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;position:relative;animation:frogBlink 3s infinite;"></div><div class="frogduck-eye-preview" style="width:18px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;position:relative;animation:frogBlink 3s infinite;"></div></div><div style="color:#aed581;font-weight:600;">Observing…</div></div>'
    },
    facepalm: {
      label: 'Facepalm Slap',
      art: '<div style="width:44px;height:20px;background:#f8bbd0;border-radius:10px 10px 8px 8px;border:2px solid #ad1457;margin:0 auto 10px;animation:faceSlap 1.5s infinite;"></div><div style="text-align:center;font-weight:600;">Facepalm</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(200,40,80,0.2);border-radius:16px;"><div class="facepalm-preview" style="width:44px;height:20px;background:#f8bbd0;border-radius:10px 10px 8px 8px;border:2px solid #ad1457;animation:faceSlap 1.5s infinite;"></div><div style="margin-top:16px;color:#ec407a;font-weight:600;">Regretting…</div></div>'
    },
    tonguebear: {
      label: 'Tongue Bear Wiggle',
      art: '<div style="display:flex;gap:32px;margin:0 auto 8px;justify-content:center;"><div class="tonguebear-ear-art" style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;"></div><div class="tonguebear-ear-art" style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;animation-delay:0.3s;"></div></div><div style="width:10px;height:10px;background:#ff4081;border-radius:0 0 6px 6px;border:2px solid #4a148c;border-top:none;margin:0 auto;animation:tongueBounce 0.8s infinite alternate;"></div><div style="text-align:center;font-weight:600;margin-top:4px;">Tongue Bear</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(120,30,160,0.2);border-radius:16px;"><div style="display:flex;gap:32px;margin-bottom:4px;"><div class="tonguebear-ear-preview" style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;"></div><div class="tonguebear-ear-preview" style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;animation-delay:0.3s;"></div></div><div style="width:10px;height:10px;background:#ff4081;border-radius:0 0 6px 6px;border:2px solid #4a148c;border-top:none;animation:tongueBounce 0.8s infinite alternate;"></div><div style="margin-top:12px;color:#ce93d8;font-weight:600;">Playing…</div></div>'
    },
    hungrydog: {
      label: 'Hungry Dog Drool',
      art: '<div style="display:flex;gap:12px;align-items:center;margin:0 auto 12px;justify-content:center;"><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(15deg);"></div><div style="width:8px;height:14px;background:#b3e5fc;border-radius:0 0 6px 6px;border:2px solid #3e2723;border-top:none;animation:droolDrip 1.5s infinite;"></div><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(-15deg);"></div></div><div style="text-align:center;font-weight:600;">Hungry Dog</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(100,70,50,0.2);border-radius:16px;"><div style="display:flex;gap:12px;align-items:center;margin-bottom:8px;"><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(15deg);"></div><div style="width:8px;height:14px;background:#b3e5fc;border-radius:0 0 6px 6px;border:2px solid #3e2723;border-top:none;animation:droolDrip 1.5s infinite;"></div><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(-15deg);"></div></div><div style="color:#8d6e63;font-weight:600;">Drooling…</div></div>'
    },
    catdog: {
      label: 'Catdog Ears',
      art: '<div style="display:flex;gap:24px;margin:0 auto 10px;justify-content:center;"><div style="width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #26a69a;animation:catEarTwitch 0.5s infinite alternate;"></div><div style="width:18px;height:16px;background:#00695c;border-radius:4px 4px 0 0;border:2px solid #004d40;transform:rotate(10deg);animation:dogEarFlop 0.7s infinite alternate;"></div></div><div style="text-align:center;font-weight:600;">Catdog</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(0,80,70,0.2);border-radius:16px;"><div style="display:flex;gap:24px;margin-bottom:8px;"><div style="width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #26a69a;animation:catEarTwitch 0.5s infinite alternate;"></div><div style="width:18px;height:16px;background:#00695c;border-radius:4px 4px 0 0;border:2px solid #004d40;transform:rotate(10deg);animation:dogEarFlop 0.7s infinite alternate;"></div></div><div style="color:#26a69a;font-weight:600;">Morphing…</div></div>'
    },
    frogchick: {
      label: 'Frogchick Peck',
      art: '<div style="width:16px;height:12px;background:#ff9800;clip-path:polygon(0% 0%,50% 100%,100% 0%);border:2px solid #c8a600;animation:beakPeck 1s infinite;transform-origin:top;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Frogchick</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(180,170,30,0.2);border-radius:16px;"><div class="frogchick-preview" style="width:16px;height:12px;background:#ff9800;clip-path:polygon(0% 0%,50% 100%,100% 0%);border:2px solid #c8a600;animation:beakPeck 1s infinite;transform-origin:top;"></div><div style="margin-top:16px;color:#ffee58;font-weight:600;">Pecking…</div></div>'
    },
    pig: {
      label: 'Pig Sniff',
      art: '<div style="width:24px;height:18px;background:#ff91a4;border:2px solid #d43750;border-radius:50%;position:relative;animation:snoutWiggle 0.4s infinite alternate;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Pig</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(200,90,110,0.2);border-radius:16px;"><div class="pig-preview" style="width:24px;height:18px;background:#ff91a4;border:2px solid #d43750;border-radius:50%;position:relative;animation:snoutWiggle 0.4s infinite alternate;"></div><div style="margin-top:16px;color:#ff91a4;font-weight:600;">Sniffing…</div></div>'
    },
    doge: {
      label: 'Doge Paw',
      art: '<div style="width:24px;height:28px;background:#e7c99e;border:3px solid #c49a5c;border-radius:10px 10px 14px 14px;position:relative;animation:pawBounce 1s infinite alternate;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Doge</div>',
      previewHtml: '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:120px;background:rgba(180,150,110,0.2);border-radius:16px;"><div class="doge-preview" style="width:24px;height:28px;background:#e7c99e;border:3px solid #c49a5c;border-radius:10px 10px 14px 14px;position:relative;animation:pawBounce 1s infinite alternate;"></div><div style="margin-top:16px;color:#e7c99e;font-weight:600;">Cheering…</div></div>'
    }
  };

  var sidebarPresets = {
    default: {
      label: 'Arklum Default',
      art: '<div style="font-size:2rem;text-align:center;margin:0 auto 8px;">●</div><div style="text-align:center;font-weight:600;">Default</div>',
      previewHtml: '<div class="sidebar-preview" style="width:240px;height:200px;margin:0 auto;background:rgba(18,20,24,0.7);backdrop-filter:blur(25px);border-right:1px solid rgba(255,255,255,0.12);border-radius:20px;display:flex;flex-direction:column;padding:16px;color:#e8e6e3;"><div style="font-size:10px;font-weight:700;text-transform:uppercase;margin:8px 0 4px;color:#a0a0a0;">Menu</div><div style="padding:6px 10px;border-radius:8px;color:#a0a0a0;">Home</div><div style="padding:6px 10px;border-radius:8px;color:#a0a0a0;">Chat</div></div>'
    },
    tonguebear: {
      label: 'Tongue Bear',
      vars: {
        '--sidebar-bg': 'rgba(60, 20, 80, 0.7)',
        '--sidebar-border': '#ab47bc',
        '--sidebar-text': '#d1c4e9',
        '--sidebar-category-color': '#ce93d8',
        '--sidebar-item-hover-bg': 'rgba(171,71,188,0.2)',
        '--sidebar-item-active-bg': '#7b1fa2',
        '--sidebar-item-active-color': '#fff'
      },
      art: '<div style="display:flex;gap:16px;justify-content:center;margin-bottom:8px;"><div style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;"></div><div style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;animation-delay:0.3s;"></div></div><div style="width:10px;height:10px;background:#ff4081;border-radius:0 0 6px 6px;border:2px solid #4a148c;border-top:none;margin:0 auto;animation:tongueBounce 0.8s infinite alternate;"></div><div style="text-align:center;font-weight:600;">Tongue Bear</div>',
      previewHtml: '<div class="sidebar-preview" style="width:240px;height:200px;margin:0 auto;background:rgba(60,20,80,0.7);backdrop-filter:blur(25px);border-right:2px solid #ab47bc;border-radius:20px;display:flex;flex-direction:column;padding:16px;color:#d1c4e9;position:relative;"><div style="position:absolute;top:10px;left:-12px;width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;"></div><div style="position:absolute;top:46px;left:-12px;width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;"></div><div style="position:absolute;bottom:14px;left:50%;transform:translateX(-50%);width:14px;height:12px;background:#ff4081;border-radius:0 0 8px 8px;border:2px solid #4a148c;border-top:none;"></div><div style="font-size:10px;font-weight:700;text-transform:uppercase;margin:8px 0 4px;color:#ce93d8;">Menu</div><div style="padding:6px 10px;border-radius:8px;color:#d1c4e9;">Home</div><div style="padding:6px 10px;border-radius:8px;background:#7b1fa2;color:#fff;">Chat</div></div>'
    },
    hungrydog: {
      label: 'Hungry Dog',
      vars: {
        '--sidebar-bg': '#1a1410',
        '--sidebar-border': '#5d4037',
        '--sidebar-text': '#bcaaa4',
        '--sidebar-category-color': '#8d6e63',
        '--sidebar-item-hover-bg': 'rgba(93,64,55,0.3)',
        '--sidebar-item-active-bg': '#3e2723',
        '--sidebar-item-active-color': '#ffcc80'
      },
      art: '<div style="display:flex;gap:8px;align-items:center;justify-content:center;margin-bottom:8px;"><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(15deg);"></div><div style="width:8px;height:14px;background:#b3e5fc;border-radius:0 0 6px 6px;border:2px solid #3e2723;border-top:none;animation:droolDrip 1.5s infinite;"></div><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(-15deg);"></div></div><div style="text-align:center;font-weight:600;">Hungry Dog</div>',
      previewHtml: '<div class="sidebar-preview" style="width:240px;height:200px;margin:0 auto;background:#1a1410;backdrop-filter:blur(0);border-right:2px solid #5d4037;border-radius:20px;display:flex;flex-direction:column;padding:16px;color:#bcaaa4;position:relative;"><div style="position:absolute;bottom:-14px;right:20px;width:10px;height:14px;background:#b3e5fc;border-radius:0 0 6px 6px;border:2px solid #3e2723;border-top:none;animation:droolDrip 1.5s infinite;"></div><div style="font-size:10px;font-weight:700;text-transform:uppercase;margin:8px 0 4px;color:#8d6e63;">Menu</div><div style="padding:6px 10px;border-radius:8px;color:#bcaaa4;">Home</div><div style="padding:6px 10px;border-radius:8px;background:#3e2723;color:#ffcc80;">Chat</div></div>'
    },
    facepalm: {
      label: 'Facepalm',
      vars: {
        '--sidebar-bg': '#1a0d14',
        '--sidebar-border': '#c2185b',
        '--sidebar-text': '#f48fb1',
        '--sidebar-category-color': '#ec407a',
        '--sidebar-item-hover-bg': 'rgba(194,24,91,0.3)',
        '--sidebar-item-active-bg': '#880e4f',
        '--sidebar-item-active-color': '#fff'
      },
      art: '<div style="width:40px;height:18px;background:#f8bbd0;border-radius:10px 10px 8px 8px;border:2px solid #ad1457;animation:faceSlap 1.5s infinite;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Facepalm</div>',
      previewHtml: '<div class="sidebar-preview" style="width:240px;height:200px;margin:0 auto;background:#1a0d14;backdrop-filter:blur(0);border-right:2px solid #c2185b;border-radius:20px;display:flex;flex-direction:column;padding:16px;color:#f48fb1;position:relative;"><div style="position:absolute;top:12px;left:12px;width:40px;height:18px;background:#f8bbd0;border-radius:10px 10px 8px 8px;border:2px solid #ad1457;transform:rotate(-5deg);"></div><div style="font-size:10px;font-weight:700;text-transform:uppercase;margin:8px 0 4px;color:#ec407a;">Menu</div><div style="padding:6px 10px;border-radius:8px;color:#f48fb1;">Home</div><div style="padding:6px 10px;border-radius:8px;background:#880e4f;color:#fff;">Chat</div></div>'
    },
    frogchick: {
      label: 'Frogchick',
      vars: {
        '--sidebar-bg': '#1a1a0a',
        '--sidebar-border': '#c8a600',
        '--sidebar-text': '#fff9c4',
        '--sidebar-category-color': '#fbc02d',
        '--sidebar-item-hover-bg': 'rgba(200,166,0,0.3)',
        '--sidebar-item-active-bg': '#f57f17',
        '--sidebar-item-active-color': '#000'
      },
      art: '<div style="width:16px;height:12px;background:#ff9800;clip-path:polygon(0% 0%,50% 100%,100% 0%);border:2px solid #c8a600;animation:beakPeck 1s infinite;transform-origin:top;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Frogchick</div>',
      previewHtml: '<div class="sidebar-preview" style="width:240px;height:200px;margin:0 auto;background:#1a1a0a;backdrop-filter:blur(0);border-right:2px solid #c8a600;border-radius:20px;display:flex;flex-direction:column;padding:16px;color:#fff9c4;position:relative;"><div style="position:absolute;top:30%;left:-8px;width:14px;height:18px;background:#ffee58;border:2px solid #fbc02d;border-radius:0 8px 8px 0;transform:rotate(-20deg);"></div><div style="font-size:10px;font-weight:700;text-transform:uppercase;margin:8px 0 4px;color:#fbc02d;">Menu</div><div style="padding:6px 10px;border-radius:8px;color:#fff9c4;">Home</div><div style="padding:6px 10px;border-radius:8px;background:#f57f17;color:#000;">Chat</div></div>'
    }
  };

  var headerPresets = {
    default: {
      label: 'Arklum Default',
      art: '<div style="font-size:2rem;text-align:center;margin:0 auto 8px;">●</div><div style="text-align:center;font-weight:600;">Default</div>',
      previewHtml: '<div style="width:100%;height:50px;background:rgba(18,20,24,0.55);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.12);border-radius:16px;display:flex;align-items:center;justify-content:center;color:#e8e6e3;font-weight:700;">Arklum Header</div>'
    },
    catdog: {
      label: 'Catdog',
      vars: {},
      art: '<div style="display:flex;gap:24px;margin:0 auto 10px;justify-content:center;"><div style="width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #26a69a;"></div><div style="width:18px;height:16px;background:#00695c;border-radius:4px 4px 0 0;border:2px solid #004d40;transform:rotate(10deg);"></div></div><div style="text-align:center;font-weight:600;">Catdog</div>',
      previewHtml: '<div style="width:100%;height:60px;background:rgba(0,80,70,0.8);backdrop-filter:blur(20px);border-bottom:2px solid #26a69a;border-radius:18px;display:flex;align-items:center;justify-content:center;color:#26a69a;text-shadow:0 0 8px rgba(38,166,154,0.5);font-weight:700;position:relative;overflow:visible;"><div style="position:absolute;top:-16px;left:20px;width:22px;height:20px;background:#00695c;border-radius:4px 4px 0 0;border:2px solid #004d40;transform:rotate(10deg);"></div><div style="position:absolute;top:-14px;right:20px;width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #26a69a;filter:drop-shadow(0 -1px 0 #004d40);"></div>Catdog Header</div>'
    },
    shark: {
      label: 'Shark',
      vars: {},
      art: '<div style="width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Shark</div>',
      previewHtml: '<div style="width:100%;height:60px;background:#0a1628;border-bottom:2px solid #1e88e5;border-radius:18px;display:flex;align-items:center;justify-content:center;color:#1e88e5;text-shadow:0 0 10px rgba(30,136,229,0.6);font-weight:700;position:relative;overflow:visible;"><div style="position:absolute;top:-18px;right:30px;width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);"></div><div style="position:absolute;bottom:-6px;left:10%;width:80%;height:8px;background:repeating-linear-gradient(90deg,#fff 0px,#fff 5px,#1565c0 5px,#1565c0 7px);border-radius:0 0 8px 8px;"></div>Shark Header</div>'
    },
    pig: {
      label: 'Piggy',
      vars: {},
      art: '<div style="width:12px;height:10px;background:#ff6680;border:2px solid #d43750;border-radius:4px 4px 0 0;transform:rotate(-15deg);margin:0 auto 10px;box-shadow:28px 0 0 -2px #ff6680,28px 0 0 0px #d43750;"></div><div style="text-align:center;font-weight:600;">Piggy</div>',
      previewHtml: '<div style="width:100%;height:60px;background:linear-gradient(135deg,#2a1018,#1e0a14);border-bottom:2px solid #ff6680;border-radius:18px;display:flex;align-items:center;justify-content:center;color:#ff91a4;text-shadow:0 0 8px rgba(255,102,128,0.5);font-weight:700;position:relative;overflow:visible;"><div style="position:absolute;top:-14px;left:20px;width:14px;height:12px;background:#ff6680;border:2px solid #d43750;border-radius:4px 4px 0 0;transform:rotate(-15deg);"></div><div style="position:absolute;top:-14px;right:20px;width:14px;height:12px;background:#ff6680;border:2px solid #d43750;border-radius:4px 4px 0 0;transform:rotate(15deg);"></div>Piggy Header</div>'
    },
    frogduck: {
      label: 'Frog Duck',
      vars: {},
      art: '<div style="display:flex;gap:20px;justify-content:center;margin-bottom:8px;"><div style="width:20px;height:20px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div><div style="width:20px;height:20px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div></div><div style="text-align:center;font-weight:600;">Frog Duck</div>',
      previewHtml: '<div style="width:100%;height:60px;background:#0d1a0d;border-bottom:2px solid #7cb342;border-radius:18px;display:flex;align-items:center;justify-content:center;color:#7cb342;text-shadow:0 0 8px rgba(124,179,66,0.5);font-weight:700;position:relative;overflow:visible;"><div style="position:absolute;top:-16px;left:30px;width:20px;height:20px;background:#fff;border:3px solid #2e7d32;border-radius:50%;box-shadow:34px 0 0 #fff,34px 0 0 3px #2e7d32;"></div>Frog Duck Header</div>'
    },
    doge: {
      label: 'Doge',
      vars: {},
      art: '<div style="width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #e7c99e;filter:drop-shadow(0 -1px 0 #c49a5c);margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Doge</div>',
      previewHtml: '<div style="width:100%;height:60px;background:linear-gradient(150deg,#2a2018,#1a1410);border-bottom:2px solid #c49a5c;border-radius:18px;display:flex;align-items:center;justify-content:center;color:#e7c99e;text-shadow:0 0 6px rgba(231,201,158,0.4);font-weight:700;position:relative;overflow:visible;"><div style="position:absolute;top:-18px;left:20px;width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #e7c99e;filter:drop-shadow(0 -1px 0 #c49a5c);"></div>Doge Header</div>'
    }
  };

  var cardsPresets = {
    default: {
      label: 'Arklum Default',
      art: '<div style="font-size:2rem;text-align:center;margin:0 auto 8px;">●</div><div style="text-align:center;font-weight:600;">Default</div>',
      previewHtml: '<div class="glass-card-preview" style="padding:20px;background:rgba(22,24,28,0.5);border:1px solid rgba(255,255,255,0.08);border-radius:16px;text-align:center;color:#e8e6e3;">Default Card</div>'
    },
    capybara: {
      label: 'Capybara',
      vars: {
        '--card-bg': 'rgba(100,60,40,0.5)',
        '--card-border': '#8b5e3c',
        '--card-text': '#fff9f0',
        '--card-shadow': '0 8px 32px rgba(0,0,0,0.4)'
      },
      art: '<div style="width:48px;height:32px;background:radial-gradient(circle at 50% 38%,#ffa726 12px,#ef6c00 14px);border-radius:50%;box-shadow:-38px 6px 0 -10px #b08050,-38px 6px 0 -7px #8b5e3c,38px 6px 0 -10px #b08050,38px 6px 0 -7px #8b5e3c;margin:0 auto 8px;"></div><div style="text-align:center;font-weight:600;">Capybara</div>',
      previewHtml: '<div class="glass-card-preview" style="padding:20px;background:rgba(100,60,40,0.5);border:1px solid #8b5e3c;border-radius:16px;text-align:center;color:#fff9f0;position:relative;overflow:visible;"><div style="position:absolute;top:-26px;left:50%;transform:translateX(-50%);width:38px;height:22px;background:radial-gradient(circle at 50% 38%,#ffa726 10px,#ef6c00 12px);border-radius:50%;box-shadow:-30px 4px 0 -8px #b08050,-30px 4px 0 -6px #8b5e3c,30px 4px 0 -8px #b08050,30px 4px 0 -6px #8b5e3c;"></div>Capybara Card</div>'
    },
    dino: {
      label: 'Dino',
      vars: {
        '--card-bg': 'rgba(0,130,140,0.5)',
        '--card-border': '#006064',
        '--card-text': '#fff',
        '--card-shadow': '0 8px 32px rgba(0,0,0,0.4)'
      },
      art: '<div style="width:60px;height:12px;background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Dino</div>',
      previewHtml: '<div class="glass-card-preview" style="padding:20px;background:rgba(0,130,140,0.5);border:1px solid #006064;border-radius:16px;text-align:center;color:#fff;position:relative;overflow:visible;"><div style="position:absolute;top:-12px;left:15px;width:calc(100% - 30px);height:12px;background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);"></div>Dino Card</div>'
    },
    frogduck: {
      label: 'Frog Duck',
      vars: {
        '--card-bg': 'rgba(100,150,50,0.5)',
        '--card-border': '#558b2f',
        '--card-text': '#dcedc8',
        '--card-shadow': '0 8px 32px rgba(0,0,0,0.4)'
      },
      art: '<div style="display:flex;gap:24px;margin:0 auto 8px;justify-content:center;"><div style="width:22px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div><div style="width:22px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div></div><div style="text-align:center;font-weight:600;">Frog Duck</div>',
      previewHtml: '<div class="glass-card-preview" style="padding:20px;background:rgba(100,150,50,0.5);border:1px solid #558b2f;border-radius:16px;text-align:center;color:#dcedc8;position:relative;overflow:visible;"><div style="position:absolute;top:-20px;left:18px;width:22px;height:22px;background:#fff;border:4px solid #2e7d32;border-radius:50%;box-shadow:34px 0 0 #fff,34px 0 0 4px #2e7d32;"></div>Frog Duck Card</div>'
    },
    shark: {
      label: 'Shark',
      vars: {
        '--card-bg': 'rgba(20,60,120,0.5)',
        '--card-border': '#1565c0',
        '--card-text': '#e3f2fd',
        '--card-shadow': '0 8px 32px rgba(0,0,0,0.4)'
      },
      art: '<div style="width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);margin:0 auto 8px;"></div><div style="text-align:center;font-weight:600;">Shark</div>',
      previewHtml: '<div class="glass-card-preview" style="padding:20px;background:rgba(20,60,120,0.5);border:1px solid #1565c0;border-radius:16px;text-align:center;color:#e3f2fd;position:relative;overflow:visible;"><div style="position:absolute;top:-18px;right:20px;width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);"></div>Shark Card</div>'
    }
  };

  var chatPresets = {
    default: {
      label: 'Default',
      art: '<div style="font-size:2rem;text-align:center;margin:0 auto 8px;">●</div><div style="text-align:center;font-weight:600;">Default</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:12px 16px;background:rgba(0,0,0,0.25);border-radius:18px;color:#e8e6e3;text-align:left;">Hello!</div>',
      bubbleStyle: 'background:rgba(0,0,0,0.25);border-radius:18px;color:#e8e6e3;padding:12px 16px;'
    },
    capybara: {
      label: 'Capybara',
      art: '<div style="width:48px;height:32px;background:radial-gradient(circle at 50% 38%,#ffa726 12px,#ef6c00 14px);border-radius:50%;box-shadow:-38px 6px 0 -10px #b08050,-38px 6px 0 -7px #8b5e3c,38px 6px 0 -10px #b08050,38px 6px 0 -7px #8b5e3c;margin:0 auto 8px;"></div><div style="text-align:center;font-weight:600;">Capybara</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:34px 16px 12px;background:linear-gradient(145deg,#c59464,#8b5e3c);border-bottom:4px solid #5c3a20;border-radius:22px;color:#fff9f0;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-22px;left:28px;width:22px;height:22px;background:radial-gradient(circle at 50% 38%,#ffa726 9px,#ef6c00 11px);border-radius:50%;box-shadow:-32px -6px 0 -8px #b08050,-32px -6px 0 -6px #8b5e3c,48px -6px 0 -8px #b08050,48px -6px 0 -6px #8b5e3c;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(145deg,#c59464,#8b5e3c);border-bottom:4px solid #5c3a20;border-radius:22px;color:#fff9f0;padding:34px 16px 12px;position:relative;overflow:visible;'
    },
    dino: {
      label: 'Dino',
      art: '<div style="width:60px;height:12px;background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Dino</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:30px 16px 12px;background:linear-gradient(135deg,#00bcd4,#00838f);border-bottom:5px solid #006064;border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-12px;left:15px;width:calc(100% - 30px);height:12px;background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(135deg,#00bcd4,#00838f);border-bottom:5px solid #006064;border-radius:22px;color:#fff;padding:30px 16px 12px;position:relative;overflow:visible;'
    },
    frogduck: {
      label: 'Frog Duck',
      art: '<div style="display:flex;gap:24px;margin:0 auto 8px;justify-content:center;"><div style="width:22px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div><div style="width:22px;height:22px;background:#fff;border:3px solid #2e7d32;border-radius:50%;"></div></div><div style="text-align:center;font-weight:600;">Frog Duck</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:30px 16px 12px;background:linear-gradient(160deg,#7cb342,#558b2f);border-bottom:5px solid #33691e;border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-20px;left:22px;width:24px;height:24px;background:#fff;border:4px solid #2e7d32;border-radius:50%;box-shadow:34px 0 0 #fff,34px 0 0 4px #2e7d32,8px 8px 0 5px #000,42px 8px 0 5px #000;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(160deg,#7cb342,#558b2f);border-bottom:5px solid #33691e;border-radius:22px;color:#fff;padding:30px 16px 12px;position:relative;overflow:visible;'
    },
    shark: {
      label: 'Shark',
      art: '<div style="width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);margin:0 auto 8px;"></div><div style="text-align:center;font-weight:600;">Shark</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:28px 16px 12px;background:linear-gradient(135deg,#1e88e5,#1565c0);border-bottom:6px solid #0d47a1;border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-18px;right:30px;width:18px;height:18px;background:#1e88e5;border:3px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);transform:rotate(10deg);"></div><div style="position:absolute;bottom:-8px;left:5%;width:90%;height:8px;background:repeating-linear-gradient(90deg,#fff 0px,#fff 4px,#1565c0 4px,#1565c0 6px);border-radius:0 0 8px 8px;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(135deg,#1e88e5,#1565c0);border-bottom:6px solid #0d47a1;border-radius:22px;color:#fff;padding:28px 16px 12px;position:relative;overflow:visible;'
    },
    heartpepe: {
      label: 'Heart Pepe',
      art: '<div style="width:28px;height:26px;background:#e53935;clip-path:path(\'M14,22 C14,22 0,13 0,7 C0,2 3,0 6,0 C9,0 14,4 14,4 C14,4 19,0 22,0 C25,0 28,2 28,7 C28,13 14,22 14,22Z\');animation:heartBeat 1.2s infinite;filter:drop-shadow(0 0 6px rgba(229,57,53,0.5));margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Heart Pepe</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:28px 16px 12px;background:linear-gradient(150deg,#f8c2d0,#e899aa);border:2px solid #d4899b;border-radius:22px;color:#4b1e28;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-24px;right:18px;width:18px;height:16px;background:#e53935;clip-path:path(\'M9,14 C9,14 0,8 0,4.5 C0,1.5 2,0 3.5,0 C5.2,0 9,2.5 9,2.5 C9,2.5 12.8,0 14.5,0 C16,0 18,1.5 18,4.5 C18,8 9,14 9,14Z\');animation:heartFloat 2.3s infinite;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(150deg,#f8c2d0,#e899aa);border:2px solid #d4899b;border-radius:22px;color:#4b1e28;padding:28px 16px 12px;position:relative;overflow:visible;'
    },
    facepalm: {
      label: 'Facepalm',
      art: '<div style="width:44px;height:20px;background:#f8bbd0;border-radius:10px 10px 8px 8px;border:2px solid #ad1457;margin:0 auto 10px;animation:faceSlap 1.5s infinite;"></div><div style="text-align:center;font-weight:600;">Facepalm</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:24px 16px 12px;background:linear-gradient(135deg,#ec407a,#c2185b);border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-12px;left:15px;width:60%;height:22px;background:#f8bbd0;border-radius:10px 10px 8px 8px;border:2px solid #ad1457;transform:rotate(-5deg);"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(135deg,#ec407a,#c2185b);border-radius:22px;color:#fff;padding:24px 16px 12px;position:relative;overflow:visible;'
    },
    tonguebear: {
      label: 'Tongue Bear',
      art: '<div style="display:flex;gap:32px;margin:0 auto 8px;justify-content:center;"><div class="tonguebear-ear-art" style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;"></div><div class="tonguebear-ear-art" style="width:16px;height:16px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;animation-delay:0.3s;"></div></div><div style="width:10px;height:10px;background:#ff4081;border-radius:0 0 6px 6px;border:2px solid #4a148c;border-top:none;margin:0 auto;animation:tongueBounce 0.8s infinite alternate;"></div><div style="text-align:center;font-weight:600;margin-top:4px;">Tongue Bear</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:28px 16px 12px;background:linear-gradient(135deg,#ab47bc,#7b1fa2);border-bottom:4px solid #4a148c;border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-16px;left:12px;width:20px;height:20px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;box-shadow:52px 0 0 0 #ab47bc,52px 0 0 3px #4a148c;"></div><div style="position:absolute;bottom:-10px;left:50%;transform:translateX(-50%);width:14px;height:12px;background:#ff4081;border-radius:0 0 8px 8px;border:2px solid #4a148c;border-top:none;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(135deg,#ab47bc,#7b1fa2);border-bottom:4px solid #4a148c;border-radius:22px;color:#fff;padding:28px 16px 12px;position:relative;overflow:visible;'
    },
    hungrydog: {
      label: 'Hungry Dog',
      art: '<div style="display:flex;gap:12px;align-items:center;margin:0 auto 12px;justify-content:center;"><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(15deg);"></div><div style="width:8px;height:14px;background:#b3e5fc;border-radius:0 0 6px 6px;border:2px solid #3e2723;border-top:none;animation:droolDrip 1.5s infinite;"></div><div style="width:16px;height:24px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(-15deg);"></div></div><div style="text-align:center;font-weight:600;">Hungry Dog</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:28px 16px 12px;background:linear-gradient(135deg,#8d6e63,#5d4037);border-bottom:5px solid #3e2723;border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-12px;left:8px;width:18px;height:22px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(15deg);box-shadow:58px 0 0 -2px #5d4037,58px 0 0 0px #3e2723;"></div><div style="position:absolute;bottom:-14px;right:20px;width:10px;height:14px;background:#b3e5fc;border-radius:0 0 6px 6px;border:2px solid #3e2723;border-top:none;animation:droolBounce 1.8s infinite;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(135deg,#8d6e63,#5d4037);border-bottom:5px solid #3e2723;border-radius:22px;color:#fff;padding:28px 16px 12px;position:relative;overflow:visible;'
    },
    catdog: {
      label: 'Catdog',
      art: '<div style="display:flex;gap:24px;margin:0 auto 10px;justify-content:center;"><div style="width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #26a69a;animation:catEarTwitch 0.5s infinite alternate;"></div><div style="width:18px;height:16px;background:#00695c;border-radius:4px 4px 0 0;border:2px solid #004d40;transform:rotate(10deg);animation:dogEarFlop 0.7s infinite alternate;"></div></div><div style="text-align:center;font-weight:600;">Catdog</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:28px 16px 12px;background:linear-gradient(135deg,#26a69a,#00695c);border-bottom:4px solid #004d40;border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-14px;left:10px;width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;border-bottom:16px solid #26a69a;filter:drop-shadow(0 -1px 0 #004d40);"></div><div style="position:absolute;top:-16px;right:16px;width:18px;height:20px;background:#00695c;border-radius:4px 4px 0 0;border:2px solid #004d40;transform:rotate(10deg);"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(135deg,#26a69a,#00695c);border-bottom:4px solid #004d40;border-radius:22px;color:#fff;padding:28px 16px 12px;position:relative;overflow:visible;'
    },
    frogchick: {
      label: 'Frogchick',
      art: '<div style="width:16px;height:12px;background:#ff9800;clip-path:polygon(0% 0%,50% 100%,100% 0%);border:2px solid #c8a600;animation:beakPeck 1s infinite;transform-origin:top;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Frogchick</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:24px 16px 12px;background:linear-gradient(160deg,#ffee58,#fbc02d);border-bottom:4px solid #c8a600;border-radius:22px;color:#3e3500;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;bottom:-10px;left:50%;transform:translateX(-50%);width:20px;height:14px;background:#ff9800;clip-path:polygon(0% 0%,50% 100%,100% 0%);border:2px solid #c8a600;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(160deg,#ffee58,#fbc02d);border-bottom:4px solid #c8a600;border-radius:22px;color:#3e3500;padding:24px 16px 12px;position:relative;overflow:visible;'
    },
    pig: {
      label: 'Pig',
      art: '<div style="width:24px;height:18px;background:#ff91a4;border:2px solid #d43750;border-radius:50%;position:relative;animation:snoutWiggle 0.4s infinite alternate;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Pig</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:28px 16px 12px;background:linear-gradient(135deg,#ff91a4,#ff6680);border-bottom:4px solid #d43750;border-radius:22px;color:#fff;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-14px;left:12px;width:14px;height:12px;background:#ff6680;border:2px solid #d43750;border-radius:4px 4px 0 0;transform:rotate(-15deg);box-shadow:48px 0 0 -2px #ff6680,48px 0 0 0px #d43750;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(135deg,#ff91a4,#ff6680);border-bottom:4px solid #d43750;border-radius:22px;color:#fff;padding:28px 16px 12px;position:relative;overflow:visible;'
    },
    doge: {
      label: 'Doge',
      art: '<div style="width:24px;height:28px;background:#e7c99e;border:3px solid #c49a5c;border-radius:10px 10px 14px 14px;position:relative;animation:pawBounce 1s infinite alternate;margin:0 auto 10px;"></div><div style="text-align:center;font-weight:600;">Doge</div>',
      previewHtml: '<div class="chat-bubble-preview" style="max-width:240px;margin:0 auto;padding:32px 16px 12px;background:linear-gradient(150deg,#f7e2c2,#e7c99e);border-bottom:5px solid #c49a5c;border-radius:22px;color:#4f370f;position:relative;overflow:visible;text-align:left;"><div style="position:absolute;top:-24px;left:12px;width:0;height:0;border-left:10px solid transparent;border-right:10px solid transparent;border-bottom:22px solid #e7c99e;filter:drop-shadow(0 -1px 0 #c49a5c);box-shadow:52px 0 0 -8px #e7c99e,52px 0 0 -6px #c49a5c;"></div>Hello!</div>',
      bubbleStyle: 'background:linear-gradient(150deg,#f7e2c2,#e7c99e);border-bottom:5px solid #c49a5c;border-radius:22px;color:#4f370f;padding:32px 16px 12px;position:relative;overflow:visible;'
    }
  };

  var root = document.documentElement;
  var selectedPresetKey = null;
  var selectedType = null;
  var chatSelectedSubType = null;

  function showPreview(type, key, subType) {
    var presets;
    if (type === 'chat') {
      presets = chatPresets;
      chatSelectedSubType = subType;
      selectedType = 'chat';
    } else {
      presets = type === 'login' ? loginPresets : (type === 'loading' ? loadingPresets : (type === 'sidebar' ? sidebarPresets : (type === 'header' ? headerPresets : cardsPresets)));
      selectedType = type;
    }
    var preset = presets[key];
    if (!preset) return;
    selectedPresetKey = key;
    var container = document.getElementById('preview-content');
    container.innerHTML = preset.previewHtml || '';
    document.getElementById('preview-title').textContent = type === 'chat' ? 'Chat Bubble Preview' : (type === 'login' ? 'Login Preview' : (type === 'loading' ? 'Loading Preview' : (type === 'sidebar' ? 'Sidebar Preview' : (type === 'header' ? 'Header Preview' : 'Card Preview'))));
    document.getElementById('preview-modal').style.display = 'flex';
  }

  function hidePreview() {
    document.getElementById('preview-modal').style.display = 'none';
    selectedPresetKey = null;
    selectedType = null;
    chatSelectedSubType = null;
  }

  function injectHeaderStyles(style) {
    var styleId = 'customize-header-inline';
    var old = document.getElementById(styleId);
    if (old) old.remove();
    if (!style) return;
    var el = document.createElement('style');
    el.id = styleId;
    el.textContent = style;
    document.head.appendChild(el);
  }

  function applyChatBubbleStyle(subType, key) {
    var preset = chatPresets[key];
    if (!preset) return;
    var botId = AppState.botInfo ? AppState.botInfo.id : null;
    if (!botId) return;
    var allWrappers = document.querySelectorAll('.message-wrapper');
    allWrappers.forEach(function(wrapper) {
      var authorId = wrapper.dataset.authorId;
      if (subType === 'self' && authorId === botId) {
        wrapper.style.cssText = preset.bubbleStyle;
        wrapper.style.position = 'relative';
        wrapper.style.overflow = 'visible';
      } else if (subType === 'other' && authorId !== botId) {
        wrapper.style.cssText = preset.bubbleStyle;
        wrapper.style.position = 'relative';
        wrapper.style.overflow = 'visible';
      }
    });
  }

  function applyPreset() {
    if (!selectedType || !selectedPresetKey) return;

    if (selectedType === 'login') {
      socket.emit('run_command', { cmd: 'customize_save_login_preset', params: { key: selectedPresetKey } });
      var loginVars = ['--login-card-bg','--login-card-border','--login-card-text','--login-title-gradient','--login-input-bg','--login-input-text','--login-input-border','--login-btn-primary-bg','--login-btn-primary-text'];
      if (selectedPresetKey === 'default') {
        loginVars.forEach(function(k) { root.style.removeProperty(k); });
        var loginCard = document.getElementById('login-card');
        if (loginCard) { loginCard.classList.remove('login-card-capybara','login-card-dino','login-card-frogduck','login-card-shark'); }
      } else {
        var preset = loginPresets[selectedPresetKey];
        if (preset && preset.vars) { Object.keys(preset.vars).forEach(function(k) { root.style.setProperty(k, preset.vars[k]); }); }
        var loginCard = document.getElementById('login-card');
        if (loginCard) {
          loginCard.classList.remove('login-card-capybara','login-card-dino','login-card-frogduck','login-card-shark');
          loginCard.classList.add('login-card-' + selectedPresetKey);
        }
      }
      showToast('Login theme saved!');
    } else if (selectedType === 'loading') {
      socket.emit('run_command', { cmd: 'customize_save_loading_preset', params: { key: selectedPresetKey } });
      var overlay = document.getElementById('connecting-overlay');
      if (overlay) {
        var preset = loadingPresets[selectedPresetKey];
        if (preset && preset.previewHtml) {
          overlay._customized = true;
          overlay.innerHTML = '<div style="text-align:center;color:var(--text);"><div style="margin-bottom:20px;">' + (preset.art || '') + '</div><div id="loading-message" style="margin-top:20px;font-size:1rem;">Loading preset applied! Reloading soon…</div></div>';
          overlay.style.display = 'flex';
          setTimeout(function() { overlay.style.display = 'none'; overlay.innerHTML = ''; overlay._customized = false; }, 2000);
        }
      }
      showToast('Loading screen saved!');
    } else if (selectedType === 'sidebar') {
      socket.emit('run_command', { cmd: 'customize_save_sidebar_preset', params: { key: selectedPresetKey } });
      var sidebarVars = ['--sidebar-bg','--sidebar-border','--sidebar-text','--sidebar-category-color','--sidebar-item-hover-bg','--sidebar-item-active-bg','--sidebar-item-active-color'];
      if (selectedPresetKey === 'default') {
        sidebarVars.forEach(function(k) { root.style.removeProperty(k); });
      } else {
        var preset = sidebarPresets[selectedPresetKey];
        if (preset && preset.vars) { Object.keys(preset.vars).forEach(function(k) { root.style.setProperty(k, preset.vars[k]); }); }
      }
      var sidebarEl = document.getElementById('sidebar');
      if (sidebarEl) {
        var decoClasses = ['sidebar-tonguebear','sidebar-hungrydog','sidebar-facepalm','sidebar-frogchick'];
        decoClasses.forEach(function(cls) { sidebarEl.classList.remove(cls); });
        if (selectedPresetKey !== 'default') { sidebarEl.classList.add('sidebar-' + selectedPresetKey); }
      }
      showToast('Sidebar theme saved!');
    } else if (selectedType === 'header') {
      socket.emit('run_command', { cmd: 'customize_save_header_preset', params: { key: selectedPresetKey } });
      var headerStyles = {
        catdog: ".page-top-bar { position: relative !important; overflow: visible !important; background: rgba(0,80,70,0.8) !important; border-bottom:2px solid #26a69a !important; color:#26a69a !important; text-shadow:0 0 8px rgba(38,166,154,0.5) !important; } .page-top-bar .header-btn, .page-top-bar .page-title { color:#26a69a !important; border-color:#26a69a !important; }",
        shark: ".page-top-bar { position: relative !important; overflow: visible !important; background: #0a1628 !important; border-bottom:2px solid #1e88e5 !important; color:#1e88e5 !important; text-shadow:0 0 10px rgba(30,136,229,0.6) !important; } .page-top-bar .header-btn, .page-top-bar .page-title { color:#1e88e5 !important; border-color:#1e88e5 !important; }",
        pig: ".page-top-bar { position: relative !important; overflow: visible !important; background: linear-gradient(135deg,#2a1018,#1e0a14) !important; border-bottom:2px solid #ff6680 !important; color:#ff91a4 !important; text-shadow:0 0 8px rgba(255,102,128,0.5) !important; } .page-top-bar .header-btn, .page-top-bar .page-title { color:#ff91a4 !important; border-color:#ff6680 !important; }",
        frogduck: ".page-top-bar { position: relative !important; overflow: visible !important; background: #0d1a0d !important; border-bottom:2px solid #7cb342 !important; color:#7cb342 !important; text-shadow:0 0 8px rgba(124,179,66,0.5) !important; } .page-top-bar .header-btn, .page-top-bar .page-title { color:#7cb342 !important; border-color:#7cb342 !important; }",
        doge: ".page-top-bar { position: relative !important; overflow: visible !important; background: linear-gradient(150deg,#2a2018,#1a1410) !important; border-bottom:2px solid #c49a5c !important; color:#e7c99e !important; text-shadow:0 0 6px rgba(231,201,158,0.4) !important; } .page-top-bar .header-btn, .page-top-bar .page-title { color:#e7c99e !important; border-color:#c49a5c !important; }"
      };
      if (selectedPresetKey === 'default') {
        injectHeaderStyles(null);
      } else {
        injectHeaderStyles(headerStyles[selectedPresetKey] || '');
      }
      var topBar = document.querySelector('.page-top-bar');
      if (topBar) {
        var hClasses = ['header-catdog','header-shark','header-pig','header-frogduck','header-doge'];
        hClasses.forEach(function(cls) { topBar.classList.remove(cls); });
        if (selectedPresetKey !== 'default') { topBar.classList.add('header-' + selectedPresetKey); }
      }
      showToast('Header theme saved!');
    } else if (selectedType === 'cards') {
      socket.emit('run_command', { cmd: 'customize_save_cards_preset', params: { key: selectedPresetKey } });
      var cardVars = ['--card-bg','--card-border','--card-text','--card-shadow'];
      if (selectedPresetKey === 'default') {
        cardVars.forEach(function(k) { root.style.removeProperty(k); });
        var allCards = document.querySelectorAll('.glass-card');
        allCards.forEach(function(card) {
          card.classList.remove('card-capybara','card-dino','card-frogduck','card-shark');
          card.style.background = '';
          card.style.borderColor = '';
          card.style.color = '';
        });
      } else {
        var preset = cardsPresets[selectedPresetKey];
        if (preset && preset.vars) {
          Object.keys(preset.vars).forEach(function(k) { root.style.setProperty(k, preset.vars[k]); });
        }
        var allCards = document.querySelectorAll('.glass-card');
        allCards.forEach(function(card) {
          card.classList.remove('card-capybara','card-dino','card-frogduck','card-shark');
          card.classList.add('card-' + selectedPresetKey);
          card.style.setProperty('background', preset.vars['--card-bg'], 'important');
          card.style.setProperty('border-color', preset.vars['--card-border'], 'important');
          card.style.setProperty('color', preset.vars['--card-text'], 'important');
        });
      }
      showToast('Card theme saved!');
    } else if (selectedType === 'chat') {
      if (!chatSelectedSubType || !selectedPresetKey) return;
      socket.emit('run_command', {
        cmd: 'customize_save_chat_preset',
        params: { subType: chatSelectedSubType, key: selectedPresetKey }
      });
      applyChatBubbleStyle(chatSelectedSubType, selectedPresetKey);
      showToast('Chat bubble saved!');
    }
    hidePreview();
  }

  document.getElementById('preview-cancel').addEventListener('click', hidePreview);
  document.getElementById('preview-apply').addEventListener('click', applyPreset);

  function buildGalleries() {
    ['login','loading','sidebar','header','cards'].forEach(function(type) {
      var container = document.getElementById(type + '-preset-gallery');
      if (!container) return;
      var presets = type === 'login' ? loginPresets : (type === 'loading' ? loadingPresets : (type === 'sidebar' ? sidebarPresets : (type === 'header' ? headerPresets : cardsPresets)));
      Object.keys(presets).forEach(function(key) {
        var preset = presets[key];
        var card = document.createElement('div');
        card.className = 'preset-card';
        card.dataset.presetKey = key;
        card.style.cssText = 'width:140px;border-radius:16px;padding:16px;background:var(--glass-bg-light);border:1px solid var(--glass-border);cursor:pointer;text-align:center;transition:all 0.2s;';
        card.innerHTML = preset.art;
        card.addEventListener('click', function() { showPreview(type, key); });
        container.appendChild(card);
      });
    });

    ['self','other'].forEach(function(subType) {
      var container = document.getElementById('chat-' + subType + '-gallery');
      if (!container) return;
      Object.keys(chatPresets).forEach(function(key) {
        var preset = chatPresets[key];
        var card = document.createElement('div');
        card.className = 'preset-card';
        card.dataset.presetKey = key;
        card.style.cssText = 'width:140px;border-radius:16px;padding:16px;background:var(--glass-bg-light);border:1px solid var(--glass-border);cursor:pointer;text-align:center;transition:all 0.2s;';
        card.innerHTML = preset.art;
        card.addEventListener('click', function() { showPreview('chat', key, subType); });
        container.appendChild(card);
      });
    });
  }

  buildGalleries();
  function highlightSavedPresets() {
    socket.emit('run_command', { cmd: 'customize_get_saved_presets', params: {} });
  }

  socket.on('customize_saved_presets', function(presets) {
    function glowContainer(containerId, presetKey) {
      var container = document.getElementById(containerId);
      if (!container) return;
      container.querySelectorAll('.preset-card').forEach(function(card) {
        card.style.boxShadow = '';
        card.style.border = '1px solid var(--glass-border)';
      });
      if (!presetKey || presetKey === 'default') return;
      var card = container.querySelector('.preset-card[data-preset-key="' + presetKey + '"]');
      if (card) {
        card.style.boxShadow = '0 0 12px var(--primary-glow)';
        card.style.border = '2px solid var(--primary)';
      }
    }

    if (presets) {
      glowContainer('login-preset-gallery', presets.login);
      glowContainer('loading-preset-gallery', presets.loading);
      glowContainer('sidebar-preset-gallery', presets.sidebar);
      glowContainer('header-preset-gallery', presets.header);
      glowContainer('cards-preset-gallery', presets.cards);
      if (presets.chat) {
        glowContainer('chat-self-gallery', presets.chat.self);
        glowContainer('chat-other-gallery', presets.chat.other);
      }
    }
  });

  highlightSavedPresets();
})();