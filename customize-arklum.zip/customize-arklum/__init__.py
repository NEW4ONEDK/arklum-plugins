import os
import json

PRESET_FILE = os.path.join(os.path.dirname(__file__), "theme.json")
LOADING_PRESET_FILE = os.path.join(os.path.dirname(__file__), "loading_theme.json")
SIDEBAR_PRESET_FILE = os.path.join(os.path.dirname(__file__), "sidebar_theme.json")
HEADER_PRESET_FILE = os.path.join(os.path.dirname(__file__), "header_theme.json")
CARDS_PRESET_FILE = os.path.join(os.path.dirname(__file__), "cards_theme.json")
CHAT_PRESET_FILE = os.path.join(os.path.dirname(__file__), "chat_theme.json")
INJECTION_FILE = os.path.join(os.path.dirname(__file__), "preset_script.html")

_INJECTION_CACHE = ""

def get_injection_script():
    global _INJECTION_CACHE
    return _INJECTION_CACHE

ANIMAL_LOADING_CSS = """
@keyframes sharkPatrol {
  0% { left: 0%; transform: translateX(-50%) rotate(-15deg); }
  45% { left: 100%; transform: translateX(-50%) rotate(15deg); }
  50% { left: 100%; transform: translateX(-50%) rotate(15deg) scaleX(-1); }
  95% { left: 0%; transform: translateX(-50%) rotate(-15deg) scaleX(-1); }
  100% { left: 0%; transform: translateX(-50%) rotate(-15deg); }
}
@keyframes dinoWave {
  0% { mask-position: -100% 0; -webkit-mask-position: -100% 0; }
  100% { mask-position: 200% 0; -webkit-mask-position: 200% 0; }
}
@keyframes capyWobble {
  0% { transform: translateY(0) rotate(-5deg); }
  100% { transform: translateY(-12px) rotate(5deg); }
}
@keyframes shadowScale {
  0% { transform: scale(1); opacity: 0.6; }
  100% { transform: scale(0.6); opacity: 0.2; }
}
@keyframes heartBeat {
  0% { transform: scale(1); }
  15% { transform: scale(1.25); }
  30% { transform: scale(1); }
  45% { transform: scale(1.25); }
  100% { transform: scale(1); }
}
@keyframes frogBlink {
  0%, 90%, 100% { transform: scaleY(1); }
  95% { transform: scaleY(0.1); }
}
@keyframes faceSlap {
  0%, 40%, 100% { transform: rotate(0deg); }
  50%, 90% { transform: rotate(-20deg); }
}
@keyframes earWiggle {
  0% { transform: rotate(-10deg); }
  100% { transform: rotate(10deg); }
}
@keyframes tongueBounce {
  0% { transform: scaleY(1); }
  100% { transform: scaleY(1.6); }
}
@keyframes droolDrip {
  0% { transform: translateY(0); opacity: 0.3; }
  50% { transform: translateY(8px); opacity: 1; }
  100% { transform: translateY(16px); opacity: 0; }
}
@keyframes catEarTwitch {
  0% { transform: rotate(-5deg); }
  100% { transform: rotate(5deg); }
}
@keyframes dogEarFlop {
  0% { transform: rotate(10deg) scaleY(1); }
  100% { transform: rotate(15deg) scaleY(0.5); }
}
@keyframes beakPeck {
  0%, 30%, 100% { transform: rotate(0deg); }
  40%, 70% { transform: rotate(-15deg); }
}
@keyframes snoutWiggle {
  0% { transform: translateX(-3px); }
  100% { transform: translateX(3px); }
}
@keyframes pawBounce {
  0% { transform: translateY(0); }
  100% { transform: translateY(-12px); }
}
"""

def _get_login_script():
    if not os.path.exists(PRESET_FILE):
        return ""
    try:
        with open(PRESET_FILE, "r", encoding="utf-8") as f:
            preset_key = json.load(f).get("key")
        if not preset_key or preset_key == "default":
            return ""

        presets = {
            "capybara": {
                "--login-card-bg": "rgba(100, 60, 40, 0.55)",
                "--login-card-border": "#8b5e3c",
                "--login-card-text": "#fff9f0",
                "--login-title-gradient": "linear-gradient(135deg, #ffa726, #ef6c00)",
                "--login-input-bg": "#5c3a20",
                "--login-input-text": "#fff9f0",
                "--login-input-border": "#8b5e3c",
                "--login-btn-primary-bg": "linear-gradient(145deg, #ffa726, #ef6c00)",
                "--login-btn-primary-text": "#fff",
            },
            "dino": {
                "--login-card-bg": "rgba(0, 130, 140, 0.5)",
                "--login-card-border": "#006064",
                "--login-card-text": "#fff",
                "--login-title-gradient": "linear-gradient(135deg, #00e5ff, #00838f)",
                "--login-input-bg": "#004d52",
                "--login-input-text": "#fff",
                "--login-input-border": "#006064",
                "--login-btn-primary-bg": "linear-gradient(135deg, #00e5ff, #00838f)",
                "--login-btn-primary-text": "#000",
            },
            "frogduck": {
                "--login-card-bg": "rgba(100, 150, 50, 0.5)",
                "--login-card-border": "#558b2f",
                "--login-card-text": "#dcedc8",
                "--login-title-gradient": "linear-gradient(135deg, #aed581, #7cb342)",
                "--login-input-bg": "#33691e",
                "--login-input-text": "#dcedc8",
                "--login-input-border": "#558b2f",
                "--login-btn-primary-bg": "linear-gradient(135deg, #7cb342, #558b2f)",
                "--login-btn-primary-text": "#000",
            },
            "shark": {
                "--login-card-bg": "rgba(20, 60, 120, 0.55)",
                "--login-card-border": "#1565c0",
                "--login-card-text": "#e3f2fd",
                "--login-title-gradient": "linear-gradient(135deg, #1e88e5, #0d47a1)",
                "--login-input-bg": "#0d47a1",
                "--login-input-text": "#fff",
                "--login-input-border": "#1565c0",
                "--login-btn-primary-bg": "linear-gradient(135deg, #1e88e5, #0d47a1)",
                "--login-btn-primary-text": "#fff",
            }
        }

        vars_data = presets.get(preset_key, {})
        if not vars_data:
            return ""

        css_js = "(function(){var r=document.documentElement;"
        for k, v in vars_data.items():
            css_js += f"r.style.setProperty('{k}','{v}');"
        css_js += "})();"

        deco_js = f"document.addEventListener('DOMContentLoaded',function(){{var c=document.getElementById('login-card');if(c){{c.classList.add('login-card-{preset_key}');}}}});"

        deco_css = """
        .login-card-capybara::before {
          content:""; position:absolute; top:-26px; left:50%; transform:translateX(-50%);
          width:38px; height:22px;
          background:radial-gradient(circle at 50% 38%,#ffa726 10px,#ef6c00 12px);
          border-radius:50%;
          box-shadow:-30px 4px 0 -8px #b08050,-30px 4px 0 -6px #8b5e3c,30px 4px 0 -8px #b08050,30px 4px 0 -6px #8b5e3c;
          z-index:3;
        }
        .login-card-dino::before {
          content:""; position:absolute; top:-12px; left:15px;
          width:calc(100% - 30px); height:12px;
          background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);
          clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);
          z-index:2;
        }
        .login-card-frogduck::before {
          content:""; position:absolute; top:-20px; left:18px;
          width:22px; height:22px;
          background:#fff;
          border:4px solid #2e7d32;
          border-radius:50%;
          box-shadow:34px 0 0 #fff,34px 0 0 4px #2e7d32,8px 6px 0 5px #000,42px 6px 0 5px #000;
          z-index:3;
        }
        .login-card-shark::before {
          content:""; position:absolute; top:-18px; right:20px;
          width:18px; height:18px;
          background:#1e88e5;
          border:3px solid #0d47a1;
          clip-path:polygon(50% 0%,0% 100%,100% 100%);
          transform:rotate(10deg);
          z-index:2;
        }
        """

        return f"<style>{deco_css}</style><script>{css_js}{deco_js}</script>"

    except Exception as e:
        print(f"[Customize] Error generating login script: {e}")
        return ""


def _get_loading_script():
    if not os.path.exists(LOADING_PRESET_FILE):
        return ""
    try:
        with open(LOADING_PRESET_FILE, "r", encoding="utf-8") as f:
            preset_key = json.load(f).get("key")
        if not preset_key or preset_key == "default":
            return ""

        loaders = {
            "shark": '<div style="width:150px;height:4px;background:#0d47a1;border-radius:2px;position:relative;margin:0 auto;"><div class="shark-fin-loader" style="position:absolute;top:-18px;left:0;width:18px;height:18px;background:#1e88e5;border:2px solid #0d47a1;clip-path:polygon(50% 0%,0% 100%,100% 100%);animation:sharkPatrol 3s ease-in-out infinite;"></div></div>',
            "dino": '<div style="width:120px;height:14px;position:relative;margin:0 auto;"><div style="width:100%;height:100%;background:repeating-linear-gradient(90deg,#006064 0px,#006064 10px,transparent 10px,transparent 16px);clip-path:polygon(0% 0%,5px 100%,10px 0%,15px 100%,20px 0%,25px 100%,30px 0%,35px 100%,40px 0%,45px 100%,50px 0%,55px 100%,60px 0%,65px 100%,70px 0%,75px 100%,80px 0%);"></div><div style="position:absolute;top:0;left:0;width:100%;height:100%;background:repeating-linear-gradient(90deg,#00e5ff 0px,#00e5ff 10px,transparent 10px,transparent 16px);clip-path:polygon(0% 0%,5px 100%,10px 0%,15px 100%,20px 0%,25px 100%,30px 0%,35px 100%,40px 0%,45px 100%,50px 0%,55px 100%,60px 0%,65px 100%,70px 0%,75px 100%,80px 0%);mask:linear-gradient(90deg,transparent,#000,transparent);animation:dinoWave 2s linear infinite;"></div></div>',
            "capybara": '<div class="capy-head-loader" style="width:48px;height:32px;background:radial-gradient(circle at 50% 38%,#ffa726 12px,#ef6c00 14px);border-radius:50%;box-shadow:-38px 6px 0 -10px #b08050,-38px 6px 0 -7px #8b5e3c,38px 6px 0 -10px #b08050,38px 6px 0 -7px #8b5e3c;animation:capyWobble 0.8s infinite alternate;margin:0 auto;"></div><div style="width:60px;height:6px;background:rgba(0,0,0,0.4);border-radius:50%;margin:15px auto 0;animation:shadowScale 0.8s infinite alternate;"></div>',
            "heartpepe": '<div class="heartpepe-loader" style="width:36px;height:32px;background:#e53935;clip-path:path(\'M18,28 C18,28 0,16 0,9 C0,3 4,0 7,0 C10.4,0 18,5 18,5 C18,5 25.6,0 29,0 C32,0 36,3 36,9 C36,16 18,28 18,28Z\');animation:heartBeat 1.2s infinite;filter:drop-shadow(0 0 8px rgba(229,57,53,0.6));margin:0 auto;"></div>',
            "frogduck_loader": '<div style="display:flex;gap:28px;justify-content:center;margin-bottom:12px;"><div class="frogduck-eye-loader" style="width:24px;height:28px;background:#fff;border:4px solid #2e7d32;border-radius:50%;position:relative;animation:frogBlink 3s infinite;"></div><div class="frogduck-eye-loader" style="width:24px;height:28px;background:#fff;border:4px solid #2e7d32;border-radius:50%;position:relative;animation:frogBlink 3s infinite;"></div></div>',
            "facepalm": '<div class="facepalm-loader" style="width:50px;height:22px;background:#f8bbd0;border-radius:10px 10px 8px 8px;border:2px solid #ad1457;animation:faceSlap 1.5s infinite;margin:0 auto;"></div>',
            "tonguebear": '<div style="display:flex;gap:40px;justify-content:center;margin-bottom:4px;"><div class="tonguebear-ear-loader" style="width:20px;height:20px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;"></div><div class="tonguebear-ear-loader" style="width:20px;height:20px;background:#ab47bc;border:3px solid #4a148c;border-radius:50%;animation:earWiggle 0.6s infinite alternate;animation-delay:0.3s;"></div></div><div class="tonguebear-tongue-loader" style="width:14px;height:12px;background:#ff4081;border-radius:0 0 8px 8px;border:2px solid #4a148c;border-top:none;animation:tongueBounce 0.8s infinite alternate;margin:0 auto;"></div>',
            "hungrydog": '<div style="display:flex;gap:16px;align-items:center;justify-content:center;margin-bottom:8px;"><div style="width:18px;height:28px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(15deg);"></div><div class="hungrydog-drool-loader" style="width:10px;height:16px;background:#b3e5fc;border-radius:0 0 6px 6px;border:2px solid #3e2723;border-top:none;animation:droolDrip 1.5s infinite;"></div><div style="width:18px;height:28px;background:#5d4037;border-radius:0 0 8px 8px;border:2px solid #3e2723;transform:rotate(-15deg);"></div></div>',
            "catdog": '<div style="display:flex;gap:30px;justify-content:center;margin-bottom:8px;"><div style="width:0;height:0;border-left:10px solid transparent;border-right:10px solid transparent;border-bottom:20px solid #26a69a;animation:catEarTwitch 0.5s infinite alternate;"></div><div style="width:22px;height:20px;background:#00695c;border-radius:4px 4px 0 0;border:2px solid #004d40;transform:rotate(10deg);animation:dogEarFlop 0.7s infinite alternate;"></div></div>',
            "frogchick": '<div class="frogchick-loader" style="width:20px;height:14px;background:#ff9800;clip-path:polygon(0% 0%,50% 100%,100% 0%);border:2px solid #c8a600;animation:beakPeck 1s infinite;transform-origin:top;margin:0 auto;"></div>',
            "pig": '<div class="pig-loader" style="width:28px;height:20px;background:#ff91a4;border:2px solid #d43750;border-radius:50%;position:relative;animation:snoutWiggle 0.4s infinite alternate;margin:0 auto;"></div>',
            "doge": '<div class="doge-loader" style="width:28px;height:32px;background:#e7c99e;border:3px solid #c49a5c;border-radius:10px 10px 14px 14px;position:relative;animation:pawBounce 1s infinite alternate;margin:0 auto;"></div>'
        }

        animal_html = loaders.get(preset_key, "")
        if not animal_html:
            return ""

        loading_html = f"""<div style="text-align:center;color:var(--text);">
            <div style="margin-bottom:20px;">{animal_html}</div>
            <div id="loading-message" style="margin-top:20px;font-size:1rem;">Loading…</div>
        </div>"""

        js = f"""
<script>
(function() {{
    var animalHtml = {json.dumps(animal_html)};
    var loadingHtml = {json.dumps(loading_html)};
    var overrideInstalled = false;
    function installOverride() {{
        if (overrideInstalled) return;
        overrideInstalled = true;
        var origShowLoading = window.showLoading;
        window.showLoading = function(message) {{
            var overlay = document.getElementById('connecting-overlay');
            if (overlay) {{
                overlay.innerHTML = loadingHtml;
                var msgEl = document.getElementById('loading-message');
                if (msgEl) msgEl.textContent = message || 'Loading…';
                overlay.style.display = 'flex';
            }}
            if (origShowLoading) {{
                origShowLoading(message);
            }}
        }};
    }}
    if (document.readyState === 'complete' || document.readyState === 'interactive') {{
        setTimeout(installOverride, 0);
    }} else {{
        window.addEventListener('DOMContentLoaded', installOverride);
    }}
}})();
</script>
"""
        return js

    except Exception as e:
        print(f"[Customize] Error generating loading script: {e}")
        return ""


def _get_sidebar_script():
    if not os.path.exists(SIDEBAR_PRESET_FILE):
        return ""
    try:
        with open(SIDEBAR_PRESET_FILE, "r", encoding="utf-8") as f:
            preset_key = json.load(f).get("key")
        if not preset_key or preset_key == "default":
            return ""

        sidebar_vars = {
            "tonguebear": {
                "--sidebar-bg": "rgba(60, 20, 80, 0.7)",
                "--sidebar-border": "#ab47bc",
                "--sidebar-text": "#d1c4e9",
                "--sidebar-category-color": "#ce93d8",
                "--sidebar-item-hover-bg": "rgba(171,71,188,0.2)",
                "--sidebar-item-active-bg": "#7b1fa2",
                "--sidebar-item-active-color": "#fff"
            },
            "hungrydog": {
                "--sidebar-bg": "#1a1410",
                "--sidebar-border": "#5d4037",
                "--sidebar-text": "#bcaaa4",
                "--sidebar-category-color": "#8d6e63",
                "--sidebar-item-hover-bg": "rgba(93,64,55,0.3)",
                "--sidebar-item-active-bg": "#3e2723",
                "--sidebar-item-active-color": "#ffcc80"
            },
            "facepalm": {
                "--sidebar-bg": "#1a0d14",
                "--sidebar-border": "#c2185b",
                "--sidebar-text": "#f48fb1",
                "--sidebar-category-color": "#ec407a",
                "--sidebar-item-hover-bg": "rgba(194,24,91,0.3)",
                "--sidebar-item-active-bg": "#880e4f",
                "--sidebar-item-active-color": "#fff"
            },
            "frogchick": {
                "--sidebar-bg": "#1a1a0a",
                "--sidebar-border": "#c8a600",
                "--sidebar-text": "#fff9c4",
                "--sidebar-category-color": "#fbc02d",
                "--sidebar-item-hover-bg": "rgba(200,166,0,0.3)",
                "--sidebar-item-active-bg": "#f57f17",
                "--sidebar-item-active-color": "#000"
            }
        }

        vars_data = sidebar_vars.get(preset_key, {})
        if not vars_data:
            return ""

        css_js = "(function(){var r=document.documentElement;"
        for k, v in vars_data.items():
            css_js += f"r.style.setProperty('{k}','{v}');"
        css_js += "})();"

        deco_js = f"document.addEventListener('DOMContentLoaded',function(){{var s=document.getElementById('sidebar');if(s){{s.classList.remove('sidebar-tonguebear','sidebar-hungrydog','sidebar-facepalm','sidebar-frogchick');if('{preset_key}'!=='default'){{s.classList.add('sidebar-{preset_key}');}}}}}});"

        sidebar_css = """
        .sidebar {
          background: var(--sidebar-bg) !important;
          border-right-color: var(--sidebar-border) !important;
        }
        .sidebar .sidebar-item {
          color: var(--sidebar-text) !important;
        }
        .sidebar .sidebar-item:hover {
          background: var(--sidebar-item-hover-bg) !important;
        }
        .sidebar .sidebar-item.active {
          background: var(--sidebar-item-active-bg) !important;
          color: var(--sidebar-item-active-color) !important;
        }
        .sidebar-category .category-header {
          color: var(--sidebar-category-color) !important;
        }
        .sidebar-tonguebear::before {
          content: "";
          position: absolute;
          top: 10px;
          left: -12px;
          width: 18px;
          height: 18px;
          background: #ab47bc;
          border: 3px solid #4a148c;
          border-radius: 50%;
          z-index: 3;
          box-shadow: 0 36px 0 0 #ab47bc, 0 36px 0 3px #4a148c;
        }
        .sidebar-tonguebear::after {
          content: "";
          position: absolute;
          bottom: 14px;
          left: 50%;
          transform: translateX(-50%);
          width: 14px;
          height: 12px;
          background: #ff4081;
          border-radius: 0 0 8px 8px;
          border: 2px solid #4a148c;
          border-top: none;
        }
        .sidebar-hungrydog::before {
          content: "";
          position: absolute;
          top: 8px;
          left: -8px;
          width: 16px;
          height: 20px;
          background: #5d4037;
          border-radius: 0 0 8px 8px;
          border: 2px solid #3e2723;
          transform: rotate(15deg);
          z-index: 3;
          box-shadow: 52px 0 0 -2px #5d4037, 52px 0 0 0px #3e2723;
        }
        .sidebar-hungrydog::after {
          content: "";
          position: absolute;
          bottom: -14px;
          right: 20px;
          width: 10px;
          height: 14px;
          background: #b3e5fc;
          border-radius: 0 0 6px 6px;
          border: 2px solid #3e2723;
          border-top: none;
          animation: droolBounce 1.8s ease-in-out infinite;
          z-index: 2;
        }
        @keyframes droolBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(3px); }
        }
        .sidebar-facepalm::before {
          content: "";
          position: absolute;
          top: 12px;
          left: 12px;
          width: 50px;
          height: 18px;
          background: #f8bbd0;
          border-radius: 10px 10px 8px 8px;
          border: 2px solid #ad1457;
          transform: rotate(-5deg);
          z-index: 3;
        }
        .sidebar-facepalm::after {
          content: "";
          position: absolute;
          top: 20px;
          left: 20px;
          width: 40px;
          height: 4px;
          background: repeating-linear-gradient(90deg, transparent 0px, transparent 6px, #ad1457 6px, #ad1457 7px);
          z-index: 3;
        }
        .sidebar-frogchick::before {
          content: "";
          position: absolute;
          top: 30%;
          left: -8px;
          width: 14px;
          height: 18px;
          background: #ffee58;
          border: 2px solid #fbc02d;
          border-radius: 0 8px 8px 0;
          transform: rotate(-20deg);
          z-index: 2;
          box-shadow: 62px 0 0 -2px #ffee58, 62px 0 0 0px #fbc02d;
        }
        """

        return f"<style>{sidebar_css}</style><script>{css_js}{deco_js}</script>"

    except Exception as e:
        print(f"[Customize] Error generating sidebar script: {e}")
        return ""


def _get_header_script():
    if not os.path.exists(HEADER_PRESET_FILE):
        return ""
    try:
        with open(HEADER_PRESET_FILE, "r", encoding="utf-8") as f:
            preset_key = json.load(f).get("key")
        if not preset_key or preset_key == "default":
            return ""

        header_styles = {
            "catdog": {
                "bg": "rgba(0, 80, 70, 0.8)",
                "border": "#26a69a",
                "color": "#26a69a",
                "glow": "0 0 8px rgba(38,166,154,0.5)"
            },
            "shark": {
                "bg": "#0a1628",
                "border": "#1e88e5",
                "color": "#1e88e5",
                "glow": "0 0 10px rgba(30,136,229,0.6)"
            },
            "pig": {
                "bg": "linear-gradient(135deg, #2a1018, #1e0a14)",
                "border": "#ff6680",
                "color": "#ff91a4",
                "glow": "0 0 8px rgba(255,102,128,0.5)"
            },
            "frogduck": {
                "bg": "#0d1a0d",
                "border": "#7cb342",
                "color": "#7cb342",
                "glow": "0 0 8px rgba(124,179,66,0.5)"
            },
            "doge": {
                "bg": "linear-gradient(150deg, #2a2018, #1a1410)",
                "border": "#c49a5c",
                "color": "#e7c99e",
                "glow": "0 0 6px rgba(231,201,158,0.4)"
            }
        }

        style = header_styles.get(preset_key, {})
        if not style:
            return ""

        header_css = f"""
        .page-top-bar {{
            position: relative !important;
            overflow: visible !important;
            background: {style['bg']} !important;
            border-bottom: 2px solid {style['border']} !important;
            color: {style['color']} !important;
            text-shadow: {style['glow']} !important;
        }}
        .page-top-bar .header-btn {{
            color: {style['color']} !important;
            border-color: {style['border']} !important;
        }}
        .page-top-bar .page-title {{
            color: {style['color']} !important;
        }}
        """

        deco_css = """
        .header-catdog::before {
          content:""; position:absolute; top:-16px; left:20px; width:22px; height:20px;
          background:#00695c; border-radius:4px 4px 0 0; border:2px solid #004d40; transform:rotate(10deg); z-index:3;
        }
        .header-catdog::after {
          content:""; position:absolute; top:-14px; right:20px; width:0; height:0;
          border-left:8px solid transparent; border-right:8px solid transparent; border-bottom:16px solid #26a69a;
          filter:drop-shadow(0 -1px 0 #004d40); z-index:3;
        }
        .header-shark::before {
          content:""; position:absolute; top:-18px; right:30px; width:18px; height:18px;
          background:#1e88e5; border:3px solid #0d47a1; clip-path:polygon(50% 0%,0% 100%,100% 100%); transform:rotate(10deg); z-index:2;
        }
        .header-shark::after {
          content:""; position:absolute; bottom:-6px; left:10%; width:80%; height:8px;
          background:repeating-linear-gradient(90deg,#fff 0px,#fff 5px,#1565c0 5px,#1565c0 7px); border-radius:0 0 8px 8px;
        }
        .header-pig::before {
          content:""; position:absolute; top:-14px; left:20px; width:14px; height:12px;
          background:#ff6680; border:2px solid #d43750; border-radius:4px 4px 0 0; transform:rotate(-15deg); z-index:3;
          box-shadow:60px 0 0 -2px #ff6680,60px 0 0 0px #d43750;
        }
        .header-frogduck::before {
          content:""; position:absolute; top:-16px; left:30px; width:20px; height:20px;
          background:#fff; border:3px solid #2e7d32; border-radius:50%;
          box-shadow:34px 0 0 #fff,34px 0 0 3px #2e7d32; z-index:3;
        }
        .header-doge::before {
          content:""; position:absolute; top:-18px; left:20px; width:0; height:0;
          border-left:8px solid transparent; border-right:8px solid transparent; border-bottom:16px solid #e7c99e;
          filter:drop-shadow(0 -1px 0 #c49a5c); z-index:3;
        }
        """

        observer_js = f"""
        <script>
        (function() {{
            var className = 'header-{preset_key}';
            var allClasses = ['header-catdog','header-shark','header-pig','header-frogduck','header-doge'];
            function addClassToHeaders() {{
                document.querySelectorAll('.page-top-bar').forEach(function(bar) {{
                    allClasses.forEach(function(cls) {{ bar.classList.remove(cls); }});
                    if (!bar.classList.contains(className)) {{
                        bar.classList.add(className);
                    }}
                }});
            }}
            function startObserver() {{
                addClassToHeaders();
                var observer = new MutationObserver(function(mutations) {{
                    addClassToHeaders();
                }});
                observer.observe(document.body, {{ childList: true, subtree: true }});
            }}
            if (document.readyState === 'complete' || document.readyState === 'interactive') {{
                setTimeout(startObserver, 0);
            }} else {{
                document.addEventListener('DOMContentLoaded', startObserver);
            }}
        }})();
        </script>
        """

        return f"<style>{header_css}{deco_css}</style>{observer_js}"

    except Exception as e:
        print(f"[Customize] Error generating header script: {e}")
        return ""


def _get_cards_script():
    if not os.path.exists(CARDS_PRESET_FILE):
        return ""
    try:
        with open(CARDS_PRESET_FILE, "r", encoding="utf-8") as f:
            preset_key = json.load(f).get("key")
        if not preset_key or preset_key == "default":
            return ""

        styles = {
            "capybara": {
                "bg": "rgba(100,60,40,0.5)", "border": "#8b5e3c", "text": "#fff9f0", "shadow": "0 8px 32px rgba(0,0,0,0.4)"
            },
            "dino": {
                "bg": "rgba(0,130,140,0.5)", "border": "#006064", "text": "#fff", "shadow": "0 8px 32px rgba(0,0,0,0.4)"
            },
            "frogduck": {
                "bg": "rgba(100,150,50,0.5)", "border": "#558b2f", "text": "#dcedc8", "shadow": "0 8px 32px rgba(0,0,0,0.4)"
            },
            "shark": {
                "bg": "rgba(20,60,120,0.5)", "border": "#1565c0", "text": "#e3f2fd", "shadow": "0 8px 32px rgba(0,0,0,0.4)"
            }
        }
        s = styles.get(preset_key)
        if not s:
            return ""

        cards_css = f"""
        .glass-card:not(#login-card) {{
            background: {s['bg']} !important;
            border-color: {s['border']} !important;
            color: {s['text']} !important;
            box-shadow: {s['shadow']} !important;
            position: relative !important;
            overflow: visible !important;
        }}
        """

        deco_css = """
        .card-capybara::before {
          content:""; position:absolute; top:-26px; left:50%; transform:translateX(-50%);
          width:38px; height:22px;
          background:radial-gradient(circle at 50% 38%,#ffa726 10px,#ef6c00 12px);
          border-radius:50%;
          box-shadow:-30px 4px 0 -8px #b08050,-30px 4px 0 -6px #8b5e3c,30px 4px 0 -8px #b08050,30px 4px 0 -6px #8b5e3c;
          z-index:3;
        }
        .card-dino::before {
          content:""; position:absolute; top:-12px; left:15px;
          width:calc(100% - 30px); height:12px;
          background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);
          clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);
          z-index:2;
        }
        .card-frogduck::before {
          content:""; position:absolute; top:-20px; left:18px;
          width:22px; height:22px;
          background:#fff;
          border:4px solid #2e7d32;
          border-radius:50%;
          box-shadow:34px 0 0 #fff,34px 0 0 4px #2e7d32,8px 6px 0 5px #000,42px 6px 0 5px #000;
          z-index:3;
        }
        .card-shark::before {
          content:""; position:absolute; top:-18px; right:20px;
          width:18px; height:18px;
          background:#1e88e5;
          border:3px solid #0d47a1;
          clip-path:polygon(50% 0%,0% 100%,100% 100%);
          transform:rotate(10deg);
          z-index:2;
        }
        """

        observer_js = f"""
        <script>
        (function() {{
            var className = 'card-{preset_key}';
            var allCardClasses = ['card-capybara','card-dino','card-frogduck','card-shark'];
            var bg = '{s["bg"]}';
            var border = '{s["border"]}';
            var text = '{s["text"]}';
            var shadow = '{s["shadow"]}';

            function styleCard(card) {{
                if (card.id === 'login-card') return;
                card.classList.remove.apply(card.classList, allCardClasses);
                card.classList.add(className);
                card.style.setProperty('background', bg, 'important');
                card.style.setProperty('border-color', border, 'important');
                card.style.setProperty('color', text, 'important');
                card.style.setProperty('box-shadow', shadow, 'important');
                card.style.setProperty('position', 'relative', 'important');
                card.style.setProperty('overflow', 'visible', 'important');
            }}

            function applyToCards() {{
                document.querySelectorAll('.glass-card').forEach(styleCard);
            }}

            function startObserver() {{
                applyToCards();
                var observer = new MutationObserver(function() {{ applyToCards(); }});
                observer.observe(document.body, {{ childList: true, subtree: true }});
            }}

            if (document.readyState === 'complete' || document.readyState === 'interactive') {{
                setTimeout(startObserver, 0);
            }} else {{
                document.addEventListener('DOMContentLoaded', startObserver);
            }}
        }})();
        </script>
        """

        return f"<style>{cards_css}{deco_css}</style>{observer_js}"

    except Exception as e:
        print(f"[Customize] Error generating cards script: {e}")
        return ""


def _get_chat_script():
    if not os.path.exists(CHAT_PRESET_FILE):
        return ""
    try:
        with open(CHAT_PRESET_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        self_key = data.get("self", "default")
        other_key = data.get("other", "default")

        bubble_styles = {
            "default": {
                "background": "rgba(0,0,0,0.25)",
                "borderRadius": "18px",
                "color": "#e8e6e3",
                "padding": "12px 16px",
                "maxWidth": "80%"
            },
            "capybara": {
                "background": "linear-gradient(145deg, #c59464, #8b5e3c)",
                "borderBottom": "4px solid #5c3a20",
                "borderRadius": "22px",
                "color": "#fff9f0",
                "padding": "34px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "dino": {
                "background": "linear-gradient(135deg, #00bcd4, #00838f)",
                "borderBottom": "5px solid #006064",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "30px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "frogduck": {
                "background": "linear-gradient(160deg, #7cb342, #558b2f)",
                "borderBottom": "5px solid #33691e",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "30px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "shark": {
                "background": "linear-gradient(135deg, #1e88e5, #1565c0)",
                "borderBottom": "6px solid #0d47a1",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "28px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "heartpepe": {
                "background": "linear-gradient(150deg, #f8c2d0, #e899aa)",
                "border": "2px solid #d4899b",
                "borderRadius": "22px",
                "color": "#4b1e28",
                "padding": "28px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "facepalm": {
                "background": "linear-gradient(135deg, #ec407a, #c2185b)",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "24px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "tonguebear": {
                "background": "linear-gradient(135deg, #ab47bc, #7b1fa2)",
                "borderBottom": "4px solid #4a148c",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "28px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "hungrydog": {
                "background": "linear-gradient(135deg, #8d6e63, #5d4037)",
                "borderBottom": "5px solid #3e2723",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "28px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "catdog": {
                "background": "linear-gradient(135deg, #26a69a, #00695c)",
                "borderBottom": "4px solid #004d40",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "28px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "frogchick": {
                "background": "linear-gradient(160deg, #ffee58, #fbc02d)",
                "borderBottom": "4px solid #c8a600",
                "borderRadius": "22px",
                "color": "#3e3500",
                "padding": "24px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "pig": {
                "background": "linear-gradient(135deg, #ff91a4, #ff6680)",
                "borderBottom": "4px solid #d43750",
                "borderRadius": "22px",
                "color": "#fff",
                "padding": "28px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            },
            "doge": {
                "background": "linear-gradient(150deg, #f7e2c2, #e7c99e)",
                "borderBottom": "5px solid #c49a5c",
                "borderRadius": "22px",
                "color": "#4f370f",
                "padding": "32px 16px 12px",
                "maxWidth": "80%",
                "position": "relative",
                "overflow": "visible"
            }
        }

        decoration_css = """
        .chat-bubble-capybara::before {
          content:""; position:absolute; top:-26px; left:50%; transform:translateX(-50%);
          width:38px; height:22px;
          background:radial-gradient(circle at 50% 38%,#ffa726 10px,#ef6c00 12px);
          border-radius:50%;
          box-shadow:-30px 4px 0 -8px #b08050,-30px 4px 0 -6px #8b5e3c,30px 4px 0 -8px #b08050,30px 4px 0 -6px #8b5e3c;
          z-index:3;
        }
        .chat-bubble-dino::before {
          content:""; position:absolute; top:-12px; left:15px;
          width:calc(100% - 30px); height:12px;
          background:repeating-linear-gradient(90deg,#006064 0px,#006064 8px,transparent 8px,transparent 14px);
          clip-path:polygon(0% 0%,4px 100%,8px 0%,12px 100%,16px 0%,20px 100%,24px 0%,28px 100%,32px 0%,36px 100%,40px 0%,44px 100%,48px 0%,52px 100%,56px 0%,60px 100%,64px 0%,68px 100%,72px 0%,76px 100%,80px 0%);
          z-index:2;
        }
        .chat-bubble-frogduck::before {
          content:""; position:absolute; top:-20px; left:18px;
          width:22px; height:22px;
          background:#fff;
          border:4px solid #2e7d32;
          border-radius:50%;
          box-shadow:34px 0 0 #fff,34px 0 0 4px #2e7d32;
          z-index:3;
        }
        .chat-bubble-frogduck::after {
          content:""; position:absolute; top:-20px; left:18px;
          width:22px; height:22px;
          background:none;
          box-shadow:8px 6px 0 5px #000,42px 6px 0 5px #000;
          border-radius:50%;
          z-index:4;
        }
        .chat-bubble-shark::before {
          content:""; position:absolute; top:-18px; right:20px;
          width:18px; height:18px;
          background:#1e88e5;
          border:3px solid #0d47a1;
          clip-path:polygon(50% 0%,0% 100%,100% 100%);
          transform:rotate(10deg);
          z-index:2;
        }
        .chat-bubble-shark::after {
          content:""; position:absolute; bottom:-8px; left:5%; width:90%; height:8px;
          background:repeating-linear-gradient(90deg,#fff 0px,#fff 4px,#1565c0 4px,#1565c0 6px);
          border-radius:0 0 8px 8px;
          z-index:1;
        }
        .chat-bubble-heartpepe::before {
          content:""; position:absolute; top:-24px; right:18px;
          width:18px; height:16px;
          background:#e53935;
          clip-path:path('M9,14 C9,14 0,8 0,4.5 C0,1.5 2,0 3.5,0 C5.2,0 9,2.5 9,2.5 C9,2.5 12.8,0 14.5,0 C16,0 18,1.5 18,4.5 C18,8 9,14 9,14Z');
          animation:heartFloat 2.3s infinite;
          z-index:3;
        }
        @keyframes heartFloat {
          0%, 100% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-7px) scale(1.15); }
        }
        .chat-bubble-facepalm::before {
          content:""; position:absolute; top:-12px; left:15px;
          width:60%; height:22px;
          background:#f8bbd0;
          border-radius:10px 10px 8px 8px;
          border:2px solid #ad1457;
          transform:rotate(-5deg);
          z-index:3;
        }
        .chat-bubble-tonguebear::before {
          content:""; position:absolute; top:-16px; left:12px;
          width:20px; height:20px;
          background:#ab47bc;
          border:3px solid #4a148c;
          border-radius:50%;
          box-shadow:52px 0 0 0 #ab47bc,52px 0 0 3px #4a148c;
          z-index:3;
        }
        .chat-bubble-tonguebear::after {
          content:""; position:absolute; bottom:-10px; left:50%; transform:translateX(-50%);
          width:14px; height:12px;
          background:#ff4081;
          border-radius:0 0 8px 8px;
          border:2px solid #4a148c;
          border-top:none;
          z-index:3;
        }
        .chat-bubble-hungrydog::before {
          content:""; position:absolute; top:-12px; left:8px;
          width:18px; height:22px;
          background:#5d4037;
          border-radius:0 0 8px 8px;
          border:2px solid #3e2723;
          transform:rotate(15deg);
          box-shadow:58px 0 0 -2px #5d4037,58px 0 0 0px #3e2723;
          z-index:3;
        }
        .chat-bubble-hungrydog::after {
          content:""; position:absolute; bottom:-14px; right:20px;
          width:10px; height:14px;
          background:#b3e5fc;
          border-radius:0 0 6px 6px;
          border:2px solid #3e2723;
          border-top:none;
          animation:droolBounce 1.8s ease-in-out infinite;
          z-index:2;
        }
        @keyframes droolBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(3px); }
        }
        .chat-bubble-catdog::before {
          content:""; position:absolute; top:-14px; left:10px;
          width:0; height:0;
          border-left:8px solid transparent; border-right:8px solid transparent;
          border-bottom:16px solid #26a69a;
          filter:drop-shadow(0 -1px 0 #004d40);
          z-index:3;
        }
        .chat-bubble-catdog::after {
          content:""; position:absolute; top:-16px; right:16px;
          width:18px; height:20px;
          background:#00695c;
          border-radius:4px 4px 0 0;
          border:2px solid #004d40;
          transform:rotate(10deg);
          z-index:3;
        }
        .chat-bubble-frogchick::before {
          content:""; position:absolute; bottom:-10px; left:50%; transform:translateX(-50%);
          width:20px; height:14px;
          background:#ff9800;
          clip-path:polygon(0% 0%,50% 100%,100% 0%);
          border:2px solid #c8a600;
          z-index:3;
        }
        .chat-bubble-pig::before {
          content:""; position:absolute; top:-14px; left:12px;
          width:14px; height:12px;
          background:#ff6680;
          border:2px solid #d43750;
          border-radius:4px 4px 0 0;
          transform:rotate(-15deg);
          box-shadow:48px 0 0 -2px #ff6680,48px 0 0 0px #d43750;
          z-index:3;
        }
        .chat-bubble-doge::before {
          content:""; position:absolute; top:-24px; left:12px;
          width:0; height:0;
          border-left:10px solid transparent; border-right:10px solid transparent;
          border-bottom:22px solid #e7c99e;
          filter:drop-shadow(0 -1px 0 #c49a5c);
          box-shadow:52px 0 0 -8px #e7c99e,52px 0 0 -6px #c49a5c;
          z-index:3;
        }
        """

        self_props = bubble_styles.get(self_key, bubble_styles["default"])
        other_props = bubble_styles.get(other_key, bubble_styles["default"])
        self_style_obj = json.dumps(self_props)
        other_style_obj = json.dumps(other_props)

        chat_js = f"""
        <script>
        (function() {{
            var selfStyles = {self_style_obj};
            var otherStyles = {other_style_obj};
            var selfKey = '{self_key}';
            var otherKey = '{other_key}';
            var observerStarted = false;
            var cachedBotId = null;

            function getBotId() {{
                if (cachedBotId) return cachedBotId;
                if (window.AppState && window.AppState.botInfo && window.AppState.botInfo.id) {{
                    cachedBotId = window.AppState.botInfo.id;
                    return cachedBotId;
                }}
                return null;
            }}

            function createBubbleWrapper(contentCol) {{
                if (contentCol.querySelector('.chat-bubble')) return contentCol.querySelector('.chat-bubble');
                var bubble = document.createElement('div');
                bubble.className = 'chat-bubble';
                while (contentCol.children.length > 1) {{
                    bubble.appendChild(contentCol.children[1]);
                }}
                contentCol.appendChild(bubble);
                return bubble;
            }}

            function applyChatStyles() {{
                var botId = getBotId();
                if (!botId) return;
                document.querySelectorAll('.message-wrapper').forEach(function(wrapper) {{
                    var authorId = wrapper.dataset.authorId;
                    var isSelf = (authorId === botId);
                    var styles = isSelf ? selfStyles : otherStyles;
                    var presetKey = isSelf ? selfKey : otherKey;
                    var contentCol = wrapper.querySelector('.message-content > div[style*="flex:1"]');
                    if (!contentCol) return;
                    var bubble = createBubbleWrapper(contentCol);
                    var decoClasses = ['chat-bubble-capybara','chat-bubble-dino','chat-bubble-frogduck','chat-bubble-shark',
                                      'chat-bubble-heartpepe','chat-bubble-facepalm','chat-bubble-tonguebear',
                                      'chat-bubble-hungrydog','chat-bubble-catdog','chat-bubble-frogchick',
                                      'chat-bubble-pig','chat-bubble-doge'];
                    decoClasses.forEach(function(cls) {{ bubble.classList.remove(cls); }});
                    if (presetKey !== 'default') {{
                        bubble.classList.add('chat-bubble-' + presetKey);
                    }}
                    Object.keys(styles).forEach(function(prop) {{
                        var cssProp = prop.replace(/([A-Z])/g, '-$1').toLowerCase();
                        bubble.style.setProperty(cssProp, styles[prop], 'important');
                    }});
                    bubble.style.maxWidth = styles.maxWidth || '80%';
                }});
            }}

            function startObserver() {{
                if (observerStarted) return;
                observerStarted = true;
                var observer = new MutationObserver(function() {{ applyChatStyles(); }});
                var chatArea = document.getElementById('chat-messages');
                if (chatArea) {{
                    observer.observe(chatArea, {{ childList: true, subtree: true }});
                }} else {{
                    observer.observe(document.body, {{ childList: true, subtree: true }});
                }}
                applyChatStyles();
            }}

            function fetchBotIdAndStart() {{
                if (getBotId()) {{
                    startObserver();
                    return;
                }}
                socket.emit('run_command', {{ cmd: 'customize_get_bot_id', params: {{}} }});
                socket.once('customize_bot_id', function(data) {{
                    if (data.id) {{
                        cachedBotId = data.id;
                        startObserver();
                    }}
                }});
            }}

            if (document.readyState === 'complete' || document.readyState === 'interactive') {{
                setTimeout(fetchBotIdAndStart, 0);
            }} else {{
                window.addEventListener('DOMContentLoaded', fetchBotIdAndStart);
            }}
        }})();
        </script>
        """
        return f"<style>{decoration_css}</style>" + chat_js

    except Exception as e:
        print(f"[Customize] Error generating chat script: {e}")
        return ""


def _write_injection_file():
    global _INJECTION_CACHE
    login_script = _get_login_script()
    loading_script = _get_loading_script()
    sidebar_script = _get_sidebar_script()
    header_script = _get_header_script()
    cards_script = _get_cards_script()
    chat_script = _get_chat_script()
    combined = ""
    if login_script:
        combined += login_script
    if loading_script:
        combined += f"<style>{ANIMAL_LOADING_CSS}</style>" + loading_script
    if sidebar_script:
        combined += sidebar_script
    if header_script:
        combined += header_script
    if cards_script:
        combined += cards_script
    if chat_script:
        combined += chat_script
    _INJECTION_CACHE = combined

    if combined:
        with open(INJECTION_FILE, "w", encoding="utf-8") as f:
            f.write(combined)
    else:
        if os.path.exists(INJECTION_FILE):
            os.remove(INJECTION_FILE)


def setup(arklum):
    _write_injection_file()

    async def hello(params, sid):
        await arklum.emit_to_sid(sid, 'notification', 'Customize Arklum is ready!')
    arklum.register_command('customize_hello', hello)

    async def get_bot_id(params, sid):
        b = arklum.bot
        if b and b.user:
            await arklum.emit_to_sid(sid, 'customize_bot_id', {'id': str(b.user.id)})
        else:
            await arklum.emit_to_sid(sid, 'customize_bot_id', {'id': None})
    arklum.register_command('customize_get_bot_id', get_bot_id)

    async def get_saved_presets(params, sid):
        presets = {}
        for fname, key in [("theme.json", "login"), ("loading_theme.json", "loading"),
                           ("sidebar_theme.json", "sidebar"), ("header_theme.json", "header"),
                           ("cards_theme.json", "cards"), ("chat_theme.json", "chat")]:
            path = os.path.join(os.path.dirname(__file__), fname)
            if os.path.exists(path):
                try:
                    with open(path, "r") as f:
                        data = json.load(f)
                    presets[key] = data.get("key") if key != "chat" else data
                except:
                    pass
        await arklum.emit_to_sid(sid, 'customize_saved_presets', presets)
    arklum.register_command('customize_get_saved_presets', get_saved_presets)

    async def save_login_preset(params, sid):
        key = params.get("key")
        if key and key in ("capybara", "dino", "frogduck", "shark", "default"):
            try:
                if key == "default":
                    if os.path.exists(PRESET_FILE):
                        os.remove(PRESET_FILE)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', 'Login theme reset to default.')
                else:
                    with open(PRESET_FILE, "w", encoding="utf-8") as f:
                        json.dump({"key": key}, f)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', f'Login theme saved: {key}')
            except Exception as e:
                print(f"[Customize] Failed to save login preset: {e}")
                await arklum.emit_to_sid(sid, 'error', {'message': 'Failed to save login theme.'})
        else:
            await arklum.emit_to_sid(sid, 'error', {'message': 'Invalid preset'})
    arklum.register_command('customize_save_login_preset', save_login_preset)

    async def save_loading_preset(params, sid):
        key = params.get("key")
        valid = ["default", "shark", "dino", "capybara", "heartpepe", "frogduck_loader",
                 "facepalm", "tonguebear", "hungrydog", "catdog", "frogchick", "pig", "doge"]
        if key and key in valid:
            try:
                if key == "default":
                    if os.path.exists(LOADING_PRESET_FILE):
                        os.remove(LOADING_PRESET_FILE)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', 'Loading screen reset to default.')
                else:
                    with open(LOADING_PRESET_FILE, "w", encoding="utf-8") as f:
                        json.dump({"key": key}, f)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', f'Loading screen saved: {key}')
            except Exception as e:
                print(f"[Customize] Failed to save loading preset: {e}")
                await arklum.emit_to_sid(sid, 'error', {'message': 'Failed to save loading screen.'})
        else:
            await arklum.emit_to_sid(sid, 'error', {'message': 'Invalid preset'})
    arklum.register_command('customize_save_loading_preset', save_loading_preset)

    async def save_sidebar_preset(params, sid):
        key = params.get("key")
        valid = ["default", "tonguebear", "hungrydog", "facepalm", "frogchick"]
        if key and key in valid:
            try:
                if key == "default":
                    if os.path.exists(SIDEBAR_PRESET_FILE):
                        os.remove(SIDEBAR_PRESET_FILE)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', 'Sidebar theme reset to default.')
                else:
                    with open(SIDEBAR_PRESET_FILE, "w", encoding="utf-8") as f:
                        json.dump({"key": key}, f)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', f'Sidebar theme saved: {key}')
            except Exception as e:
                print(f"[Customize] Failed to save sidebar preset: {e}")
                await arklum.emit_to_sid(sid, 'error', {'message': 'Failed to save sidebar theme.'})
        else:
            await arklum.emit_to_sid(sid, 'error', {'message': 'Invalid preset'})
    arklum.register_command('customize_save_sidebar_preset', save_sidebar_preset)

    async def save_header_preset(params, sid):
        key = params.get("key")
        valid = ["default", "catdog", "shark", "pig", "frogduck", "doge"]
        if key and key in valid:
            try:
                if key == "default":
                    if os.path.exists(HEADER_PRESET_FILE):
                        os.remove(HEADER_PRESET_FILE)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', 'Header theme reset to default.')
                else:
                    with open(HEADER_PRESET_FILE, "w", encoding="utf-8") as f:
                        json.dump({"key": key}, f)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', f'Header theme saved: {key}')
            except Exception as e:
                print(f"[Customize] Failed to save header preset: {e}")
                await arklum.emit_to_sid(sid, 'error', {'message': 'Failed to save header theme.'})
        else:
            await arklum.emit_to_sid(sid, 'error', {'message': 'Invalid preset'})
    arklum.register_command('customize_save_header_preset', save_header_preset)

    async def save_cards_preset(params, sid):
        key = params.get("key")
        valid = ["default", "capybara", "dino", "frogduck", "shark"]
        if key and key in valid:
            try:
                if key == "default":
                    if os.path.exists(CARDS_PRESET_FILE):
                        os.remove(CARDS_PRESET_FILE)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', 'Card theme reset to default.')
                else:
                    with open(CARDS_PRESET_FILE, "w", encoding="utf-8") as f:
                        json.dump({"key": key}, f)
                    _write_injection_file()
                    await arklum.emit_to_sid(sid, 'notification', f'Card theme saved: {key}')
            except Exception as e:
                print(f"[Customize] Failed to save cards preset: {e}")
                await arklum.emit_to_sid(sid, 'error', {'message': 'Failed to save card theme.'})
        else:
            await arklum.emit_to_sid(sid, 'error', {'message': 'Invalid preset'})
    arklum.register_command('customize_save_cards_preset', save_cards_preset)

    async def save_chat_preset(params, sid):
        sub = params.get("subType")
        key = params.get("key")
        valid = ["default", "capybara", "dino", "frogduck", "shark", "heartpepe", "facepalm", "tonguebear", "hungrydog", "catdog", "frogchick", "pig", "doge"]
        if sub in ("self", "other") and key in valid:
            try:
                data = {}
                if os.path.exists(CHAT_PRESET_FILE):
                    with open(CHAT_PRESET_FILE, "r") as f:
                        data = json.load(f)
                data[sub] = key
                with open(CHAT_PRESET_FILE, "w") as f:
                    json.dump(data, f)
                _write_injection_file()
                await arklum.emit_to_sid(sid, 'notification', f'Chat {sub} preset saved: {key}')
            except Exception as e:
                print(f"[Customize] Failed to save chat preset: {e}")
                await arklum.emit_to_sid(sid, 'error', {'message': 'Failed to save chat bubble preset.'})
        else:
            await arklum.emit_to_sid(sid, 'error', {'message': 'Invalid preset'})
    arklum.register_command('customize_save_chat_preset', save_chat_preset)

    def get_dashboard():
        path = os.path.join(os.path.dirname(__file__), "dashboard.html")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        return "<p>Dashboard not found.</p>"
    arklum.add_sidebar_item("customize-arklum", "/plugins/customize-arklum/icon.png", "Customize", get_dashboard)